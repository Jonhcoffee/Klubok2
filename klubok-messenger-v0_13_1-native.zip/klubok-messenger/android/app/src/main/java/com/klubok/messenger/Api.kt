package com.klubok.messenger

import com.google.gson.Gson
import com.google.gson.JsonParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Request
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import retrofit2.HttpException
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.Multipart
import retrofit2.http.PATCH
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Part
import retrofit2.http.Path
import retrofit2.http.Query
import java.io.IOException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLException

data class User(
    val id: String, val username: String, val phone: String? = null, val createdAt: String? = null,
    val displayName: String? = null, val bio: String? = null, val avatar: String? = null, val lastSeenAt: String? = null,
)
data class AuthResponse(val token: String, val user: User)
/** kind: photo | video | voice | file */
data class Attachment(val id: String, val name: String? = null, val size: Long = 0, val mime: String? = null, val kind: String = "file", val dur: Int? = null)
data class Message(
    val id: String, val fromId: String, val toId: String, val text: String, val createdAt: String,
    val attachment: Attachment? = null, val system: Boolean = false, val preview: String? = null,
)
data class GroupInfo(val id: String, val name: String, val avatar: String? = null, val memberCount: Int = 0)
/** Ответ сервера: для личного чата заполнен user, для группового — group. */
data class ConversationDto(val user: User?, val group: GroupInfo?, val last: Message?, val unread: Int)
/** Личная переписка (то, что умеет текущий экран списка). Групповые чаты появятся в списке на следующем этапе интерфейса. */
data class Conversation(val user: User, val last: Message?, val unread: Int)
data class MessagesResponse(val messages: List<Message>, val peerReadAt: String?)
data class AuthBody(val username: String, val password: String)
data class SendBody(val toId: String, val text: String)
data class ApiError(val error: String? = null)

interface MessengerApi {
    @POST("api/auth/register") suspend fun register(@Body body: AuthBody): AuthResponse
    @POST("api/auth/login") suspend fun login(@Body body: AuthBody): AuthResponse
    @GET("api/users") suspend fun users(@Query("q") query: String): List<User>
    @GET("api/conversations") suspend fun conversationsRaw(): List<ConversationDto>
    @GET("api/messages/{userId}") suspend fun messages(@Path("userId") userId: String): MessagesResponse
    @POST("api/messages") suspend fun send(@Body body: SendBody): Message

    // ---- 0.10: профиль и безопасность ----
    @GET("api/me") suspend fun me(): MeResponse
    @PATCH("api/me") suspend fun updateMe(@Body body: ProfileBody): User
    @GET("api/privacy") suspend fun privacy(): Privacy
    @PUT("api/privacy") suspend fun setPrivacy(@Body body: Privacy): Privacy
    @POST("api/security/password") suspend fun changePassword(@Body body: PasswordBody): PasswordResult
    @GET("api/security/sessions") suspend fun sessions(): List<SessionInfo>
    @DELETE("api/security/sessions/{id}") suspend fun endSession(@Path("id") id: String): OkResponse
    @POST("api/security/logout-others") suspend fun logoutOthers(): OkResponse
    @GET("api/blocked") suspend fun blocked(): List<String>
    @PUT("api/blocked/{userId}") suspend fun block(@Path("userId") userId: String): List<String>
    @DELETE("api/blocked/{userId}") suspend fun unblock(@Path("userId") userId: String): List<String>

    // ---- 0.10: группы ----
    @POST("api/groups") suspend fun createGroup(@Body body: GroupBody): GroupFull
    @GET("api/groups/{id}") suspend fun group(@Path("id") id: String): GroupFull
    @POST("api/groups/{id}/leave") suspend fun leaveGroup(@Path("id") id: String): OkResponse

    // ---- 0.10: медиа ----
    @Multipart @POST("api/files")
    suspend fun upload(@Part file: MultipartBody.Part, @Part("duration") duration: RequestBody? = null): UploadedFile
    @POST("api/messages") suspend fun sendMedia(@Body body: SendMediaBody): Message

    // ---- 0.10: уведомления и звонки (основа) ----
    @POST("api/devices") suspend fun registerDevice(@Body body: DeviceBody): OkResponse
    @GET("api/unread") suspend fun unread(): UnreadResponse
    @POST("api/calls") suspend fun startCall(@Body body: CallBody): CallInfo
    @GET("api/calls/incoming") suspend fun incomingCalls(): List<CallInfo>
    @POST("api/calls/{id}/answer") suspend fun answerCall(@Path("id") id: String): CallInfo
    @POST("api/calls/{id}/decline") suspend fun declineCall(@Path("id") id: String): CallInfo
    @POST("api/calls/{id}/end") suspend fun endCall(@Path("id") id: String): CallInfo

    // ---- 0.10: семья ----
    @GET("api/families") suspend fun families(): List<Family>
    @POST("api/families") suspend fun createFamily(@Body body: FamilyBody): Family
    @POST("api/families/join") suspend fun joinFamily(@Body body: JoinBody): Family
    @GET("api/families/{id}/events") suspend fun events(@Path("id") id: String): List<FamilyEvent>
    @POST("api/families/{id}/events") suspend fun addEvent(@Path("id") id: String, @Body body: FamilyEvent): FamilyEvent
    @DELETE("api/families/{id}/events/{item}") suspend fun deleteEvent(@Path("id") id: String, @Path("item") item: String): OkResponse
    @GET("api/families/{id}/shopping") suspend fun shopping(@Path("id") id: String): List<ShopItem>
    @POST("api/families/{id}/shopping") suspend fun addShopItem(@Path("id") id: String, @Body body: ShopItem): ShopItem
    @PATCH("api/families/{id}/shopping/{item}") suspend fun updateShopItem(@Path("id") id: String, @Path("item") item: String, @Body body: ShopItem): ShopItem
    @POST("api/families/{id}/shopping-clear") suspend fun clearBought(@Path("id") id: String): List<ShopItem>
    @GET("api/families/{id}/notes") suspend fun notes(@Path("id") id: String): List<FamilyNote>
    @POST("api/families/{id}/notes") suspend fun addNote(@Path("id") id: String, @Body body: FamilyNote): FamilyNote
    @PATCH("api/families/{id}/notes/{item}") suspend fun updateNote(@Path("id") id: String, @Path("item") item: String, @Body body: FamilyNote): FamilyNote
    @DELETE("api/families/{id}/notes/{item}") suspend fun deleteNote(@Path("id") id: String, @Path("item") item: String): OkResponse
    @GET("api/families/{id}/album") suspend fun album(@Path("id") id: String): List<AlbumPhoto>
    @POST("api/families/{id}/album") suspend fun addPhoto(@Path("id") id: String, @Body body: AlbumBody): AlbumPhoto
    @POST("api/families/{id}/album/{item}/like") suspend fun likePhoto(@Path("id") id: String, @Path("item") item: String): AlbumPhoto
    @DELETE("api/families/{id}/album/{item}") suspend fun deletePhoto(@Path("id") id: String, @Path("item") item: String): OkResponse
}

/** Старый экран списка ждёт личные переписки — групповые отфильтровываем здесь. */
suspend fun MessengerApi.conversations(): List<Conversation> =
    conversationsRaw().mapNotNull { d -> d.user?.let { Conversation(it, d.last, d.unread) } }

data class OkResponse(val ok: Boolean = true)
data class MeResponse(val user: User, val privacy: Privacy, val blocked: List<String> = emptyList())
data class ProfileBody(val displayName: String? = null, val bio: String? = null, val avatar: String? = null)
/** lastSeen: all | contacts | nobody;  whoCanWrite: all | contacts */
data class Privacy(val lastSeen: String = "all", val readReceipts: Boolean = true, val whoCanWrite: String = "all")
data class PasswordBody(val currentPassword: String, val newPassword: String)
data class PasswordResult(val token: String, val message: String? = null)
data class SessionInfo(val id: String, val device: String? = null, val ip: String? = null, val at: String? = null, val lastAt: String? = null, val current: Boolean = false)
data class GroupBody(val name: String, val memberIds: List<String>)
data class GroupFull(val id: String, val name: String, val ownerId: String, val memberIds: List<String>, val members: List<User>? = null, val createdAt: String? = null)
data class UploadedFile(val id: String, val name: String? = null, val mime: String? = null, val size: Long = 0, val kind: String = "file", val url: String? = null)
data class SendMediaBody(val toId: String, val text: String = "", val fileId: String)
data class DeviceBody(val token: String, val platform: String = "android")
data class PushItem(val id: String, val title: String? = null, val body: String? = null, val chatId: String? = null, val at: String? = null)
data class UnreadResponse(val total: Int = 0, val notifications: List<PushItem> = emptyList())
data class CallBody(val toId: String, val video: Boolean = false)
/** status: ringing | active | declined | missed | ended */
data class CallInfo(val id: String, val fromId: String, val toId: String, val video: Boolean = false, val status: String = "ringing", val createdAt: String? = null)
data class FamilyBody(val name: String)
data class JoinBody(val code: String)
data class Family(val id: String, val name: String, val ownerId: String, val memberIds: List<String>, val inviteCode: String? = null)
data class FamilyEvent(val id: String? = null, val title: String, val date: String, val time: String? = null, val note: String? = null, val by: String? = null)
data class ShopItem(val id: String? = null, val text: String, val qty: String? = null, val done: Boolean = false, val by: String? = null)
data class FamilyNote(val id: String? = null, val title: String = "", val text: String = "", val color: String = "yellow", val pinned: Boolean = false, val by: String? = null)
data class AlbumBody(val fileId: String, val caption: String = "")
data class AlbumPhoto(val id: String, val fileId: String, val caption: String = "", val likes: List<String> = emptyList(), val by: String? = null)

/** Turns whatever the user typed into a valid base URL ending with "/", or null if it is not a URL. */
fun normalizeServerUrl(raw: String): String? {
    var s = raw.trim()
    if (s.isEmpty()) return null
    if (!s.startsWith("http://", true) && !s.startsWith("https://", true)) {
        val local = Regex("^(localhost|\\d{1,3}(\\.\\d{1,3}){3})(:\\d+)?(/.*)?$").matches(s)
        s = (if (local) "http://" else "https://") + s
    }
    if (!s.endsWith("/")) s += "/"
    return if (s.toHttpUrlOrNull() != null) s else null
}

fun createApi(baseUrl: String, token: () -> String): MessengerApi {
    val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .addInterceptor(Interceptor { chain ->
            val t = token()
            val request = if (t.isNotEmpty()) chain.request().newBuilder().header("Authorization", "Bearer $t").build() else chain.request()
            chain.proceed(request)
        })
        .build()
    return Retrofit.Builder()
        .baseUrl(baseUrl)
        .client(client)
        .addConverterFactory(GsonConverterFactory.create())
        .build()
        .create(MessengerApi::class.java)
}

fun isUnauthorized(t: Throwable): Boolean = t is HttpException && t.code() == 401

fun isNetworkProblem(t: Throwable): Boolean = t is IOException

fun describeError(t: Throwable): String = when (t) {
    is HttpException -> {
        val body = runCatching { t.response()?.errorBody()?.string() }.getOrNull()
        val msg = runCatching { Gson().fromJson(body, ApiError::class.java)?.error }.getOrNull()
        msg ?: "Ошибка сервера (${t.code()})"
    }
    is SSLException -> "Проблема с защищённым соединением. Проверьте адрес сервера (https/http)."
    is UnknownHostException, is ConnectException, is SocketTimeoutException ->
        "Не удалось подключиться к серверу. Проверьте адрес в «Настройках подключения» и интернет."
    is IOException -> "Нет связи с сервером. Проверьте интернет."
    else -> "Что-то пошло не так. Попробуйте ещё раз."
}

val TOPIC_REGEX = Regex("^[A-Za-z0-9_-]{10,64}$")

/**
 * Asks ntfy.sh for the latest tunnel address that the PC published under the secret word.
 * Returns null if nothing was found or ntfy.sh is unreachable.
 */
suspend fun fetchTunnelUrl(topic: String): String? = withContext(Dispatchers.IO) {
    if (!TOPIC_REGEX.matches(topic)) return@withContext null
    runCatching {
        val client = OkHttpClient.Builder()
            .connectTimeout(8, TimeUnit.SECONDS)
            .readTimeout(10, TimeUnit.SECONDS)
            .build()
        val request = Request.Builder().url("https://ntfy.sh/$topic/json?poll=1&since=12h").build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return@use null
            val lines = response.body?.string().orEmpty().lines().filter { it.isNotBlank() }
            lines.asReversed().firstNotNullOfOrNull { line ->
                val obj = JsonParser.parseString(line).asJsonObject
                if (obj.get("event")?.asString == "message") obj.get("message")?.asString?.trim() else null
            }
        }
    }.getOrNull()
}
