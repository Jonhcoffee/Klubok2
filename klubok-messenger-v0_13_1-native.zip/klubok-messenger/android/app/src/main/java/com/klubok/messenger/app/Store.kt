package com.klubok.messenger.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.google.gson.Gson
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File
import java.util.Calendar
import kotlin.random.Random

data class User(val id: String, val username: String)

data class Msg(
    val id: String,
    val from: String,
    val to: String,
    val text: String,
    val at: Long,
    val pending: Boolean = false,
    val rd: Boolean = false,
    val sys: Boolean = false,
)

data class Group(val id: String, val name: String, val members: List<String>, val owner: String)

data class DB(
    val users: List<User>,
    val me: String?,
    val pw: Map<String, String>,
    val msgs: List<Msg>,
    val groups: List<Group>,
    val reads: Map<String, Long>,
    val blocked: List<String>,
    val readRcpt: Boolean,
)

data class Conv(val user: User, val last: Msg, val unread: Int)
data class Banner(val title: String, val body: String, val peer: String)

val BOT_NAMES = listOf("Маша", "Дима", "Лена", "Клубок")

val BOT_REPLIES: Map<String, List<String>> = mapOf(
    "Маша" to listOf("Ого, класс!", "Ха-ха, согласна 😄", "Давай обсудим вечером", "Скинь фотки, когда будут", "Я как раз об этом думала"),
    "Дима" to listOf("Понял, принял 👍", "Сейчас гляну", "Окей, договорились", "Ща, минутку", "Ну такое… давай лучше завтра"),
    "Лена" to listOf("Спасибо, что написал(а)!", "Это так мило 🥰", "Расскажи подробнее", "Ммм, интересно", "Я за!"),
    "Клубок" to listOf(
        "Я демо-бот. Попробуйте смайлики и галочки ✓✓",
        "Отправьте один смайлик — он станет крупным 😎",
        "Галочки станут яркими, когда я «прочитаю» сообщение",
    ),
)

val STATUS: Map<String, String> = mapOf(
    "Маша" to "в сети", "Дима" to "был(а) 10 мин назад", "Лена" to "был(а) вчера", "Клубок" to "в сети",
)

private val CHATTER = listOf("Ты тут? Есть минутка?", "Смотри, что нашла 👀", "Не забудь про вечер 😉", "Привет! Как день?", "Скинь адрес, пожалуйста")
private val NAME_RE = Regex("^[\\p{L}\\p{N}_]{3,24}$")

private fun seed(): DB {
    val t = now()
    val cal = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 12); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }
    val noon = cal.timeInMillis
    fun m(from: String, to: String, text: String, at: Long) = Msg(rid(), from, to, text, at)
    val msgs = listOf(
        m("u_Клубок", "ME", "Добро пожаловать в klubok! Это демо с вашим дизайном 💜", t - 2 * DAY),
        m("u_Маша", "ME", "Привет! Ты сегодня свободен?", noon - DAY + 3 * HOUR),
        m("ME", "u_Маша", "Привет! Да, после шести", noon - DAY + (3.1 * HOUR).toLong()),
        m("u_Маша", "ME", "Отлично, тогда кофе ☕", noon - DAY + (3.2 * HOUR).toLong()),
        m("u_Дима", "ME", "Скинул тебе файлы, глянь", t - 5 * 60_000L),
        m("u_Лена", "ME", "🔥", t - 40 * 60_000L),
        m("u_Маша", "g_dacha", "Кто едет в субботу на дачу?", t - 3 * HOUR),
        m("u_Лена", "g_dacha", "Я за! Возьму мангал 🔥", t - 170 * 60_000L),
        m("u_Дима", "g_dacha", "Я на машине, могу забрать всех", t - 160 * 60_000L),
    )
    return DB(
        users = BOT_NAMES.map { User("u_$it", it) },
        me = null,
        pw = emptyMap(),
        msgs = msgs,
        groups = listOf(Group("g_dacha", "Дача 🌿", listOf("ME", "u_Маша", "u_Лена", "u_Дима"), "u_Маша")),
        reads = emptyMap(),
        blocked = emptyList(),
        readRcpt = true,
    )
}

class Store private constructor(ctx: Context) {
    private val gson = Gson()
    private val file = File(ctx.filesDir, "klubok-native.json")
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val fails = HashMap<String, Pair<Int, Long>>()
    private var life: Job? = null
    private var toastJob: Job? = null
    private var bannerJob: Job? = null

    var db by mutableStateOf(load())
        private set
    val typing = mutableStateMapOf<String, String>()
    var banner by mutableStateOf<Banner?>(null)
        private set
    var toastText by mutableStateOf<String?>(null)
        private set

    /** Какой чат сейчас открыт на экране (чтобы не показывать баннер и сразу читать). */
    var currentChat: String? = null

    private fun load(): DB {
        return try {
            if (file.exists()) gson.fromJson(file.readText(), DB::class.java) ?: seed() else seed()
        } catch (e: Exception) {
            seed()
        }
    }

    private fun save() {
        try { file.writeText(gson.toJson(db)) } catch (_: Exception) { }
    }

    private fun upd(f: (DB) -> DB) { db = f(db); save() }

    // ---------- запросы ----------
    val me: User? get() = db.users.find { it.id == db.me }

    fun userById(id: String): User? =
        db.users.find { it.id == id } ?: db.groups.find { it.id == id }?.let { User(it.id, it.name) }

    fun nameOf(id: String): String = userById(id)?.username ?: ""

    fun convs(): List<Conv> {
        val me = db.me ?: return emptyList()
        val lasts = LinkedHashMap<String, Msg>()
        val unread = HashMap<String, Int>()
        for (m in db.msgs) {
            val peer: String
            if (isG(m.to)) {
                val g = db.groups.find { it.id == m.to } ?: continue
                if (!g.members.contains(me)) continue
                peer = g.id
            } else {
                if (m.from != me && m.to != me) continue
                peer = if (m.from == me) m.to else m.from
            }
            val cur = lasts[peer]
            if (cur == null || m.at >= cur.at) lasts[peer] = m
            if (!m.sys && m.from != me && m.at > (db.reads["$me:$peer"] ?: 0L)) unread[peer] = (unread[peer] ?: 0) + 1
        }
        return lasts.mapNotNull { (id, last) -> userById(id)?.let { Conv(it, last, unread[id] ?: 0) } }
            .sortedByDescending { it.last.at }
    }

    fun unreadTotal(): Int = convs().sumOf { it.unread }

    fun thread(peer: String): List<Msg> {
        val me = db.me ?: return emptyList()
        val l = if (isG(peer)) db.msgs.filter { it.to == peer }
        else db.msgs.filter { (it.from == me && it.to == peer) || (it.from == peer && it.to == me) }
        return l.sortedBy { it.at }
    }

    fun otherUsers(query: String): List<User> {
        val q = query.trim().lowercase()
        return db.users.filter { it.id != db.me && (q.isEmpty() || it.username.lowercase().contains(q)) }
    }

    fun isBlocked(id: String) = !isG(id) && db.blocked.contains(id)

    // ---------- вход ----------
    fun auth(register: Boolean, nameRaw: String, pass: String): String? {
        val name = nameRaw.trim()
        val key = name.lowercase()
        if (!NAME_RE.matches(name)) return "Имя: 3–24 символа — буквы, цифры и _"
        if (pass.isEmpty()) return "Введите пароль"
        if (BOT_NAMES.any { it.lowercase() == key }) return "Это имя занято демо-ботом — выберите другое"
        val f = fails[key]
        if (f != null && f.second > now() && f.first >= 5) return "Слишком много попыток. Подождите ${(f.second - now() + 999) / 1000} с"
        val exist = db.users.find { it.username.lowercase() == key }
        var d = db
        val user: User
        if (register) {
            if (pass.length < 8) return "Пароль должен быть не короче 8 символов"
            if (exist != null) return "Это имя уже занято"
            user = User("u_$name", name)
            d = d.copy(users = d.users + user, pw = d.pw + (name to hash(pass + name)))
        } else {
            if (exist == null) return "Такого аккаунта нет — откройте вкладку «Регистрация»"
            val ph = d.pw[exist.username]
            if (ph != null && ph != hash(pass + exist.username)) {
                val cur = if (f != null && f.second > now()) f else Pair(0, now() + 30_000L)
                val n = cur.first + 1
                fails[key] = Pair(n, cur.second)
                return if (n >= 5) "Слишком много попыток. Подождите 30 секунд"
                else "Неверное имя пользователя или пароль (попытка $n из 5)"
            }
            user = exist
        }
        fails.remove(key)
        val id = user.id
        d = d.copy(
            me = id,
            msgs = d.msgs.map { it.copy(from = if (it.from == "ME") id else it.from, to = if (it.to == "ME") id else it.to) },
            groups = d.groups.map { g ->
                g.copy(members = g.members.map { if (it == "ME") id else it }, owner = if (g.owner == "ME") id else g.owner)
            },
        )
        db = d; save()
        startLife()
        return null
    }

    fun logout() { upd { it.copy(me = null) }; typing.clear() }

    // ---------- сообщения ----------
    fun markRead(peer: String) {
        val me = db.me ?: return
        upd { it.copy(reads = it.reads + ("$me:$peer" to now())) }
    }

    fun send(peer: String, text: String) {
        val me = db.me ?: return
        val m = Msg(rid(), me, peer, text, now(), pending = true)
        upd { it.copy(msgs = it.msgs + m) }
        val blocked = isBlocked(peer)
        scope.launch {
            delay(350)
            upd { d -> d.copy(msgs = d.msgs.map { if (it.id == m.id) it.copy(pending = false) else it }) }
            if (!blocked) {
                if (isG(peer)) {
                    delay(1150)
                    upd { d -> d.copy(msgs = d.msgs.map { if (it.id == m.id) it.copy(rd = true) else it }) }
                } else {
                    delay(950)
                    upd { it.copy(reads = it.reads + ("$peer:$me" to now())) }
                }
            }
        }
        if (!blocked) botReaction(peer, text)
    }

    private fun replyFor(name: String, text: String): String {
        if (emojiCount(text) > 0) return text.trim()
        return (BOT_REPLIES[name] ?: listOf("👍")).random()
    }

    private fun botReaction(peerId: String, text: String) {
        val targets: List<String> = if (isG(peerId)) {
            val g = db.groups.find { it.id == peerId } ?: return
            g.members.filter { BOT_NAMES.contains(nameOf(it)) }.shuffled().take(1 + Random.nextInt(2))
        } else if (BOT_NAMES.contains(nameOf(peerId))) listOf(peerId) else emptyList()
        targets.forEachIndexed { i, id ->
            if (db.blocked.contains(id)) return@forEachIndexed
            val name = nameOf(id)
            scope.launch {
                delay(900L + i * 1600L)
                typing[peerId] = name
                delay(1300L + Random.nextLong(1000L))
                typing.remove(peerId)
                deliver(id, peerId, replyFor(name, text))
            }
        }
    }

    fun deliver(from: String, to: String, text: String) {
        if (db.me == null) return
        if (db.blocked.contains(from)) return
        val peerKey = if (isG(to)) to else from
        val msg = Msg(rid(), from, to, text, now())
        upd { it.copy(msgs = it.msgs + msg) }
        if (currentChat == peerKey) { markRead(peerKey); return }
        val sender = nameOf(from)
        val title = if (isG(peerKey)) nameOf(peerKey) + " · " + sender else sender
        banner = Banner(title, text, peerKey)
        bannerJob?.cancel()
        bannerJob = scope.launch { delay(4000); banner = null }
    }

    fun dismissBanner() { banner = null }

    fun clearChat(peer: String) {
        val ids = thread(peer).map { it.id }.toSet()
        upd { it.copy(msgs = it.msgs.filter { m -> !ids.contains(m.id) }) }
    }

    fun toggleBlock(id: String) {
        upd { it.copy(blocked = if (it.blocked.contains(id)) it.blocked - id else it.blocked + id) }
    }

    fun toast(t: String) {
        toastText = t
        toastJob?.cancel()
        toastJob = scope.launch { delay(2200); toastText = null }
    }

    /** «Живая» жизнь демо: боты иногда пишут сами. */
    private fun startLife() {
        if (life != null) return
        life = scope.launch {
            while (true) {
                delay(35_000)
                val me = db.me ?: continue
                if (Random.nextFloat() < 0.5f) {
                    val bots = db.users.filter {
                        BOT_NAMES.contains(it.username) && it.username != "Клубок" &&
                            !db.blocked.contains(it.id) && currentChat != it.id
                    }
                    if (bots.isNotEmpty()) deliver(bots.random().id, me, CHATTER.random())
                }
            }
        }
    }

    fun resume() { if (db.me != null) startLife() }

    companion object {
        @Volatile private var inst: Store? = null
        fun get(ctx: Context): Store = inst ?: synchronized(this) {
            inst ?: Store(ctx.applicationContext).also { inst = it }
        }
    }
}
