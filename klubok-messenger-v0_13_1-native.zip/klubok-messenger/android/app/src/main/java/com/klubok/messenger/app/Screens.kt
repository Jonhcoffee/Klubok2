package com.klubok.messenger.app

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.matchParentSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.BiasAlignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.klubok.messenger.R

// =============================================================== ВХОД

@Composable
fun AuthScreen(store: Store, onDone: () -> Unit) {
    var reg by remember { mutableStateOf(false) }
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var show by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf("") }
    fun submit() {
        val e = store.auth(reg, user, pass)
        if (e != null) err = e else onDone()
    }
    Column(Modifier.fillMaxSize().background(K.Bg).verticalScroll(rememberScrollState()).imePadding()) {
        val heroShape = RoundedCornerShape(bottomStart = 36.dp, bottomEnd = 36.dp)
        Box(
            Modifier.fillMaxWidth().clip(heroShape)
                .background(Brush.verticalGradient(listOf(Color(0xFF1B2D6B), Color(0xFF071027)))),
        ) {
            Image(
                painterResource(R.drawable.k_hero), null,
                Modifier.fillMaxWidth().height(215.dp).alpha(0.8f)
                    .fadeMask(Brush.verticalGradient(0f to Color.Black, 0.55f to Color.Black, 1f to Color.Transparent)),
                contentScale = ContentScale.Crop,
                alignment = BiasAlignment(-0.6f, -0.2f),
            )
            Box(
                Modifier.matchParentSize()
                    .background(Brush.verticalGradient(0f to Color(0x59251947), 0.45f to Color(0x00251947))),
            )
            Image(
                painterResource(R.drawable.k_sparkles), null,
                Modifier.align(Alignment.TopEnd).padding(end = 26.dp, top = 210.dp).size(44.dp),
            )
            Column(Modifier.statusBarsPadding().padding(start = 22.dp, end = 22.dp, top = 34.dp, bottom = 34.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Image(painterResource(R.drawable.k_logo), null, Modifier.width(60.dp))
                    Text("Клубок", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Black, letterSpacing = (-1.1).sp)
                }
                Text(
                    buildAnnotatedString {
                        append("Заходи в\n")
                        withStyle(SpanStyle(color = K.Yellow)) { append("Клубок") }
                    },
                    color = Color.White, fontSize = 42.sp, lineHeight = 42.sp, fontWeight = FontWeight.Black, letterSpacing = (-2).sp,
                    modifier = Modifier.padding(top = 100.dp),
                )
                Text(
                    "Мессенджер для своих: пиши, делись смайликами и не теряй друзей.",
                    color = Color.White.copy(alpha = 0.92f), fontSize = 15.sp, lineHeight = 21.sp, fontWeight = FontWeight.Medium,
                    modifier = Modifier.padding(top = 12.dp),
                )
            }
        }
        Column(Modifier.padding(horizontal = 20.dp)) {
            Row(Modifier.padding(top = 20.dp).fillMaxWidth().clip(CircleShape).background(K.Panel).padding(4.dp)) {
                listOf("Вход", "Регистрация").forEachIndexed { i, t ->
                    val sel = (i == 1) == reg
                    Box(
                        Modifier.weight(1f).clip(CircleShape)
                            .background(if (sel) K.Yellow else Color.Transparent)
                            .clickable { reg = i == 1; err = "" }.padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center,
                    ) { Text(t, color = if (sel) K.On else K.Muted, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold) }
                }
            }
            KField(user, { user = it }, "Имя пользователя", Modifier.padding(top = 14.dp))
            KField(
                pass, { pass = it }, "Пароль", Modifier.padding(top = 14.dp),
                password = true, reveal = show, imeAction = ImeAction.Done, onDone = { submit() },
                trailing = {
                    Text(
                        if (show) "Скрыть" else "Показать", color = K.Violet, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.clip(CircleShape).clickable { show = !show }.padding(horizontal = 10.dp, vertical = 8.dp),
                    )
                },
            )
            if (reg) Text("Минимум 8 символов", color = K.Muted, fontSize = 12.sp, modifier = Modifier.padding(start = 4.dp, top = 6.dp))
            Text(err, color = K.Danger, fontSize = 14.sp, modifier = Modifier.padding(top = 14.dp).height(20.dp))
            GradientButton(if (reg) "Создать аккаунт →" else "Войти →", { submit() }, Modifier.padding(top = 2.dp))
            Column(
                Modifier.padding(start = 4.dp, end = 4.dp, top = 22.dp, bottom = 24.dp).fillMaxWidth()
                    .border(1.dp, K.Line, RoundedCornerShape(22.dp)).padding(horizontal = 16.dp, vertical = 12.dp),
            ) {
                Text(
                    buildAnnotatedString {
                        withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append("Демо-режим. ") }
                        append("Сервер не нужен: всё хранится на этом телефоне. Зарегистрируйтесь (пароль от 8 символов) — следующий вход потребует тот же пароль; после 5 неверных попыток вход блокируется на 30 секунд. Можно завести несколько аккаунтов и переключаться между ними через «Выйти».")
                    },
                    color = K.Muted, fontSize = 12.5.sp, lineHeight = 18.sp,
                )
            }
        }
    }
}

// =============================================================== СПИСОК ЧАТОВ

@Composable
fun ListScreen(
    store: Store,
    ui: Ui,
    onOpenChat: (String) -> Unit,
    onNewChat: () -> Unit,
    onNav: (String) -> Unit,
) {
    val convs = store.convs()
    val me = store.db.me ?: ""
    val badge = convs.sumOf { it.unread }
    Column(Modifier.fillMaxSize().deco()) {
        val shape = RoundedCornerShape(bottomStart = 32.dp, bottomEnd = 32.dp)
        Box(
            Modifier.fillMaxWidth().shadow(8.dp, shape)
                .background(Brush.verticalGradient(listOf(Color(0xFF1B2D6B), Color(0xFF0E1B39)))),
        ) {
            Image(
                painterResource(R.drawable.k_hero), null,
                Modifier.matchParentSize().alpha(0.85f).fadeMask(
                    Brush.horizontalGradient(0f to Color.Transparent, 0.05f to Color.Transparent, 0.6f to Color.Black, 1f to Color.Black),
                ),
                contentScale = ContentScale.Crop,
                alignment = BiasAlignment(-0.4f, -0.24f),
            )
            Box(
                Modifier.matchParentSize()
                    .background(Brush.verticalGradient(listOf(Color(0x1A251947), Color(0x73251947)))),
            )
            Image(
                painterResource(R.drawable.k_sparkles), null,
                Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(end = 112.dp, top = 12.dp).size(20.dp),
            )
            Row(
                Modifier.statusBarsPadding().padding(start = 20.dp, end = 8.dp, top = 14.dp, bottom = 18.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Image(painterResource(R.drawable.k_logo), null, Modifier.width(42.dp))
                        Text("Клубок", color = K.Ink, fontSize = 28.sp, fontWeight = FontWeight.Black, letterSpacing = (-1.1).sp)
                    }
                    Text("@" + (store.me?.username ?: ""), color = K.Muted, fontSize = 12.8.sp)
                }
                IconBtn({ store.toast("Блокировка PIN-кодом появится в следующем этапе") }) {
                    SvgIcon(Ic.lock, K.Muted, 24.dp)
                }
            }
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (convs.isEmpty()) {
                Column(Modifier.fillMaxWidth().padding(horizontal = 32.dp, vertical = 40.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Пока нет переписок", color = K.Ink, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("Нажмите «+» и найдите собеседника по имени.", color = K.Muted, fontSize = 14.sp)
                }
            } else {
                LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(top = 8.dp, bottom = 96.dp)) {
                    items(convs, key = { it.user.id }) { c ->
                        val l = c.last
                        val who = when {
                            l.from == me -> "Вы: "
                            isG(c.user.id) && !l.sys -> store.nameOf(l.from) + ": "
                            else -> ""
                        }
                        Row(
                            Modifier.fillMaxWidth().clickable { onOpenChat(c.user.id) }.padding(horizontal = 20.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(14.dp),
                        ) {
                            AvatarFor(c.user, 52.dp)
                            Column(Modifier.weight(1f)) {
                                Text(c.user.username, color = K.Ink, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(
                                    who + l.text.replace("\n", " "),
                                    color = if (c.unread > 0) K.Ink else K.Muted, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                )
                            }
                            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(listTime(l.at), color = if (c.unread > 0) K.Accent else K.Muted, fontSize = 12.sp)
                                if (c.unread > 0) {
                                    Text(
                                        if (c.unread > 99) "99+" else c.unread.toString(),
                                        color = K.On, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                                        modifier = Modifier.background(K.Accent, CircleShape).padding(horizontal = 8.dp, vertical = 2.dp),
                                    )
                                }
                            }
                        }
                    }
                }
            }
            Box(
                Modifier.align(Alignment.BottomEnd).padding(end = 20.dp, bottom = 20.dp).size(58.dp)
                    .shadow(8.dp, CircleShape).background(K.Accent, CircleShape)
                    .clip(CircleShape).clickable {
                        ui.sheet = listOf(
                            SheetItem("Новый чат", icon = { Pic(R.drawable.k_chat, 26.dp) }, onClick = onNewChat),
                            SheetItem("Новая группа", icon = { SvgIcon(Ic.users, K.Yellow, 21.dp) }, onClick = { store.toast("Создание групп — в следующем этапе") }),
                        )
                    },
                contentAlignment = Alignment.Center,
            ) { SvgIcon(Ic.plus, K.On, 26.dp, 2.4f) }
        }
        NavBar("list", badge, onNav)
    }
}

// =============================================================== НОВЫЙ ЧАТ

@Composable
fun NewChatScreen(store: Store, onBack: () -> Unit, onOpen: (String) -> Unit) {
    var q by remember { mutableStateOf("") }
    val users = store.otherUsers(q)
    Column(Modifier.fillMaxSize().deco().statusBarsPadding().imePadding()) {
        Row(Modifier.padding(horizontal = 4.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconBtn(onBack) { SvgIcon(Ic.back, K.Ink, 24.dp) }
            Text("Новый чат", color = K.Ink, fontSize = 20.sp, fontWeight = FontWeight.Black)
        }
        KField(q, { q = it }, "Найти по имени", Modifier.padding(start = 16.dp, end = 16.dp, bottom = 8.dp), imeAction = ImeAction.Search)
        if (users.isEmpty()) {
            Text(
                "Никого не найдено. Собеседник должен зарегистрироваться в приложении.",
                color = K.Muted, fontSize = 14.sp, modifier = Modifier.padding(horizontal = 32.dp, vertical = 40.dp),
            )
        } else {
            LazyColumn(Modifier.weight(1f)) {
                items(users, key = { it.id }) { u ->
                    Row(
                        Modifier.fillMaxWidth().clickable { onOpen(u.id) }.padding(horizontal = 20.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                    ) {
                        Avatar(u.username, 44.dp)
                        Text(u.username, color = K.Ink, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }
        }
    }
}

// =============================================================== СЕМЬЯ (заглушка этапа 1)

@Composable
fun FamilyScreen(badge: Int, onNav: (String) -> Unit) {
    Column(Modifier.fillMaxSize().deco()) {
        Row(Modifier.statusBarsPadding().padding(start = 20.dp, end = 20.dp, top = 10.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Семья", color = K.Ink, fontSize = 24.sp, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
        }
        Column(Modifier.weight(1f).fillMaxWidth().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Image(painterResource(R.drawable.k_mascot), null, Modifier.size(150.dp))
            Spacer(Modifier.height(16.dp))
            Text("Семейный раздел скоро", color = K.Ink, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text("Календарь, покупки, заметки и альбом появятся в следующих этапах.", color = K.Muted, fontSize = 14.sp)
        }
        NavBar("family", badge, onNav)
    }
}

// =============================================================== ПРОФИЛЬ (минимум этапа 1)

@Composable
fun ProfileScreen(store: Store, ui: Ui, badge: Int, onNav: (String) -> Unit, onLogout: () -> Unit) {
    val name = store.me?.username ?: ""
    Column(Modifier.fillMaxSize().deco()) {
        Column(
            Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).statusBarsPadding().padding(horizontal = 20.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(Modifier.height(10.dp))
            Avatar(name.ifEmpty { "?" }, 112.dp)
            Text(name, color = K.Ink, fontSize = 24.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(top = 12.dp))
            Text("@$name", color = K.Muted, fontSize = 14.sp)
            Spacer(Modifier.height(24.dp))
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(K.Panel).clickable {
                    ui.confirm = ConfirmData("Выйти из аккаунта?", "Переписки останутся на этом телефоне.", "Выйти", onLogout)
                }.padding(horizontal = 16.dp, vertical = 13.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Box(Modifier.size(38.dp).background(K.Panel2, RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                    SvgIcon(Ic.out, K.Danger, 20.dp)
                }
                Text("Выйти", color = K.Danger, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
            Text(
                "Настройки, безопасность и уведомления появятся в этапе 2.",
                color = K.Muted, fontSize = 12.5.sp, modifier = Modifier.padding(top = 18.dp),
            )
        }
        NavBar("profile", badge, onNav)
    }
}
