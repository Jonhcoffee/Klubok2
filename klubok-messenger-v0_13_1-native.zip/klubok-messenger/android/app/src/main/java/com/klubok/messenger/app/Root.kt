package com.klubok.messenger.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

sealed class Route {
    object Auth : Route()
    object Chats : Route()
    object Family : Route()
    object Profile : Route()
    object NewChat : Route()
    class Chat(val peer: String) : Route()
}

@Composable
fun KlubokApp(store: Store) {
    val ui = remember { Ui() }
    var route by remember { mutableStateOf<Route>(if (store.db.me == null) Route.Auth else Route.Chats) }
    val canGoBack = route != Route.Auth && route != Route.Chats

    BackHandler(enabled = ui.sheet != null || ui.confirm != null || canGoBack) {
        when {
            ui.sheet != null -> ui.sheet = null
            ui.confirm != null -> ui.confirm = null
            else -> route = Route.Chats
        }
    }

    val badge = store.unreadTotal()
    val nav: (String) -> Unit = { k ->
        route = when (k) { "family" -> Route.Family; "profile" -> Route.Profile; else -> Route.Chats }
    }

    Box(Modifier.fillMaxSize().background(K.Bg)) {
        when (val r = route) {
            is Route.Auth -> AuthScreen(store) { route = Route.Chats }
            is Route.Chats -> ListScreen(store, ui, { route = Route.Chat(it) }, { route = Route.NewChat }, nav)
            is Route.Family -> FamilyScreen(badge, nav)
            is Route.Profile -> ProfileScreen(store, ui, badge, nav) { store.logout(); route = Route.Auth }
            is Route.NewChat -> NewChatScreen(store, { route = Route.Chats }) { route = Route.Chat(it) }
            is Route.Chat -> ChatScreen(store, ui, r.peer) { route = Route.Chats }
        }
        val b = store.banner
        if (b != null && route != Route.Auth) {
            BannerCard(b, { store.dismissBanner(); route = Route.Chat(b.peer) }, Modifier.align(Alignment.TopCenter).statusBarsPadding())
        }
        val t = store.toastText
        if (t != null) ToastCard(t, Modifier.align(Alignment.BottomCenter).padding(bottom = 96.dp))
        val sh = ui.sheet
        if (sh != null) SheetOverlay(sh) { ui.sheet = null }
        val cf = ui.confirm
        if (cf != null) ConfirmOverlay(cf) { ui.confirm = null }
    }
}
