package com.klubok.messenger

import android.content.Context

/** Remembers the server address and the login, so the app does not ask for them on every start. */
class SessionStore(context: Context) {
    private val prefs = context.getSharedPreferences("klubok_session", Context.MODE_PRIVATE)

    var server: String
        get() = prefs.getString("server", null) ?: BuildConfig.API_BASE_URL
        set(value) { prefs.edit().putString("server", value).apply() }
    var topic: String
        get() = prefs.getString("topic", "") ?: ""
        set(value) { prefs.edit().putString("topic", value).apply() }
    var token: String
        get() = prefs.getString("token", "") ?: ""
        set(value) { prefs.edit().putString("token", value).apply() }
    var userId: String
        get() = prefs.getString("userId", "") ?: ""
        set(value) { prefs.edit().putString("userId", value).apply() }
    var username: String
        get() = prefs.getString("username", "") ?: ""
        set(value) { prefs.edit().putString("username", value).apply() }

    var textScale: Float
        get() = prefs.getFloat("textScale", 1f)
        set(value) { prefs.edit().putFloat("textScale", value).apply() }
    var chatScale: Float
        get() = prefs.getFloat("chatScale", 1f)
        set(value) { prefs.edit().putFloat("chatScale", value).apply() }

    fun clearSession() { prefs.edit().remove("token").remove("userId").remove("username").apply() }
}
