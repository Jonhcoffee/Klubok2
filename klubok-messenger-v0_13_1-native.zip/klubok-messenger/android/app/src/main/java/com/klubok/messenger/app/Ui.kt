package com.klubok.messenger.app

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.BiasAlignment
import com.klubok.messenger.R
import kotlin.math.abs

/** Палитра демо (переменные :root из klubok-demo.html). */
object K {
    val Yellow = Color(0xFFFFC72C)
    val Violet = Color(0xFF7951E7)
    val Orchid = Color(0xFF9B6BFF)
    val Berry = Color(0xFF3946EA)
    val Mint = Color(0xFF7CF2CF)
    val Bg = Color(0xFF071027)
    val Panel = Color(0xFF0E1B39)
    val Panel2 = Color(0xFF15264D)
    val Accent = Color(0xFF8152FA)
    val Muted = Color(0xFF9AA8D0)
    val Ink = Color(0xFFF4F6FF)
    val Danger = Color(0xFFFF7A7A)
    val On = Color(0xFFFFFFFF)
    val Fg = Color(0xFF7F8DB5)
    val Line = Color(0xFF2B3D6A)
    val Brand = Brush.linearGradient(listOf(Color(0xFF7951E7), Color(0xFF9B6BFF)))
}

// ---------------------------------------------------------------- иконки (SVG-пути из демо)

object Ic {
    val back = listOf("M19 12H5", "M12 19l-7-7 7-7")
    val lock = listOf("M6 11h12a2 2 0 0 1 2 2v6a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2v-6a2 2 0 0 1 2-2z", "M8 11V7a4 4 0 0 1 8 0v4")
    val phone = listOf("M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8.1 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z")
    val video = listOf("M4 6h10a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2z", "M22 8l-6 4 6 4z")
    val bksp = listOf("M21 5H9l-6 7 6 7h12a1 1 0 0 0 1-1V6a1 1 0 0 0-1-1z", "M17 9l-5 5M12 9l5 5")
    val mic = listOf("M12 2a3 3 0 0 1 3 3v6a3 3 0 0 1-6 0V5a3 3 0 0 1 3-3z", "M5 11a7 7 0 0 0 14 0M12 18v4")
    val plus = listOf("M12 5v14M5 12h14")
    val users = listOf("M9 4a4 4 0 1 1 0 8 4 4 0 0 1 0-8z", "M1 21c0-4 3.6-6 8-6s8 2 8 6", "M17 4a4 4 0 0 1 0 8M23 21c0-3-2-5-5-5.7")
    val trash = listOf("M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6")
    val shield = listOf("M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z")
    val out = listOf("M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4", "M16 17l5-5-5-5", "M21 12H9")
}

private val pathCache = HashMap<String, Path>()
private fun path(d: String): Path = pathCache.getOrPut(d) { PathParser().parsePathString(d).toPath() }

@Composable
fun SvgIcon(paths: List<String>, tint: Color, size: Dp = 24.dp, stroke: Float = 2f, modifier: Modifier = Modifier) {
    Canvas(modifier.size(size)) {
        val s = this.size.minDimension / 24f
        withTransform({ scale(s, s, Offset.Zero) }) {
            for (d in paths) drawPath(path(d), tint, style = Stroke(width = stroke, cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
    }
}

@Composable
fun DotsIcon(tint: Color, size: Dp = 22.dp) {
    Canvas(Modifier.size(size)) {
        val s = this.size.minDimension / 24f
        for (y in listOf(5f, 12f, 19f)) drawCircle(tint, radius = 1.6f * s, center = Offset(12f * s, y * s))
    }
}

@Composable
fun Pic(res: Int, size: Dp, modifier: Modifier = Modifier, alpha: Float = 1f, filter: ColorFilter? = null) {
    Image(painterResource(res), null, modifier.size(size), contentScale = ContentScale.Fit, alpha = alpha, colorFilter = filter)
}

/** Тёмная круглая кнопка-иконка 44x44. */
@Composable
fun IconBtn(onClick: () -> Unit, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Box(modifier.size(44.dp).clip(CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) { content() }
}

// ---------------------------------------------------------------- фон: узор, градиенты

private val STAR_BIG = lazy { path("M24 14c1 8 6 13 14 14-8 1-13 6-14 14-1-8-6-13-14-14 8-1 13-6 14-14z") }
private val STAR_SMALL = lazy { path("M104 84c.8 6 4.5 9.7 10.5 10.5-6 .8-9.7 4.5-10.5 10.5-.8-6-4.5-9.7-10.5-10.5 6-.8 9.7-4.5 10.5-10.5z") }
private val RING = lazy { path("M79 60a9 9 0 1 1-18 0 9 9 0 0 1 18 0z") }
private val RING_A = lazy { path("M62 58c4 3 11 3 16 0M64 65c3-6 3-12 0-17M60 56c1 0 2 0 3 1") }
private val RING_B = lazy { path("M78 66c6 4 8 1 10 7") }

/** Фон «deco»: тёмный фон, мягкие цветные пятна и узор из звёздочек, точек и клубочков. */
fun Modifier.deco(spotTopRight: Boolean = false): Modifier = this.drawBehind {
    drawRect(K.Bg)
    val r1 = 330.dp.toPx()
    val r2 = 300.dp.toPx()
    if (spotTopRight) {
        drawRect(Brush.radialGradient(listOf(Color(0x337B4DF0), Color.Transparent), center = Offset(size.width, 0f), radius = r1))
        drawRect(Brush.radialGradient(listOf(Color(0x21E0338F), Color.Transparent), center = Offset(0f, size.height), radius = 320.dp.toPx()))
    } else {
        drawRect(Brush.radialGradient(listOf(Color(0x3D7B4DF0), Color.Transparent), center = Offset(size.width, size.height), radius = r1))
        drawRect(Brush.radialGradient(listOf(Color(0x21E0338F), Color.Transparent), center = Offset(0f, size.height * 0.55f), radius = r2))
    }
    val tile = 140.dp.toPx()
    val sc = tile / 140f
    val white = Color.White.copy(alpha = 0.07f)
    var y = 0f
    while (y < size.height) {
        var x = 0f
        while (x < size.width) {
            withTransform({ translate(x, y); scale(sc, sc, Offset.Zero) }) {
                drawPath(STAR_BIG.value, white)
                drawPath(STAR_SMALL.value, white)
                drawCircle(white, 2.5f, Offset(96f, 22f))
                drawCircle(white, 2f, Offset(30f, 100f))
                drawCircle(white, 1.8f, Offset(128f, 128f))
                val st = Stroke(width = 1.6f, cap = StrokeCap.Round)
                drawPath(RING.value, white, style = st)
                drawPath(RING_A.value, white, style = st)
                drawPath(RING_B.value, white, style = st)
            }
            x += tile
        }
        y += tile
    }
}

/** Маска-градиент по альфе (как mask-image в CSS). */
fun Modifier.fadeMask(brush: Brush): Modifier =
    this.graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
        .drawWithContent {
            drawContent()
            drawRect(brush = brush, blendMode = BlendMode.DstIn)
        }

// ---------------------------------------------------------------- аватары

private val AVG = listOf(
    listOf(Color(0xFF7048FF), Color(0xFFB23BC8)),
    listOf(Color(0xFF5BD68A), Color(0xFF2FA3A0)),
    listOf(Color(0xFFE5758F), Color(0xFF9A6BD6)),
    listOf(Color(0xFFFFB23E), Color(0xFFE5758F)),
    listOf(Color(0xFF4CA8F0), Color(0xFF7048FF)),
)

@Composable
fun Avatar(name: String, size: Dp) {
    var h = 0
    for (ch in name.lowercase()) h = h * 31 + ch.code
    val g = AVG[abs(h) % AVG.size]
    Box(
        Modifier.size(size).background(Brush.linearGradient(g), CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        Text(name.take(1).uppercase(), color = Color.White, fontSize = (size.value * 0.42f).sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun GroupAvatar(size: Dp) {
    Box(
        Modifier.size(size).background(Brush.linearGradient(listOf(Color(0xFF7951E7), Color(0xFF3946EA))), CircleShape),
        contentAlignment = Alignment.Center,
    ) { SvgIcon(Ic.users, Color.White, size * 0.5f) }
}

@Composable
fun AvatarFor(user: User, size: Dp) {
    if (isG(user.id)) GroupAvatar(size) else Avatar(user.username, size)
}

// ---------------------------------------------------------------- поле ввода с плавающей подписью

@Composable
fun KField(
    value: String,
    onValue: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    password: Boolean = false,
    reveal: Boolean = false,
    imeAction: ImeAction = ImeAction.Next,
    onDone: () -> Unit = {},
    trailing: (@Composable () -> Unit)? = null,
) {
    var focused by remember { mutableStateOf(false) }
    val up = focused || value.isNotEmpty()
    Box(
        modifier.fillMaxWidth().height(58.dp)
            .clip(CircleShape).background(K.Panel2)
            .border(2.dp, if (focused) K.Yellow else Color.Transparent, CircleShape),
    ) {
        Text(
            label,
            color = if (focused) K.Violet else K.Fg,
            fontSize = if (up) 12.sp else 16.sp,
            modifier = Modifier.padding(start = 22.dp, top = if (up) 7.dp else 17.dp),
        )
        BasicTextField(
            value = value,
            onValueChange = onValue,
            singleLine = true,
            textStyle = TextStyle(color = K.Ink, fontSize = 16.sp, fontWeight = FontWeight.Medium),
            cursorBrush = SolidColor(K.Yellow),
            visualTransformation = if (password && !reveal) PasswordVisualTransformation() else VisualTransformation.None,
            keyboardOptions = KeyboardOptions(
                capitalization = KeyboardCapitalization.None,
                keyboardType = if (password) KeyboardType.Password else KeyboardType.Text,
                imeAction = imeAction,
            ),
            keyboardActions = KeyboardActions(onDone = { onDone() }, onGo = { onDone() }),
            modifier = Modifier.fillMaxSize()
                .padding(start = 22.dp, end = if (trailing != null) 96.dp else 20.dp, top = 27.dp)
                .onFocusChanged { focused = it.isFocused },
        )
        if (trailing != null) Box(Modifier.align(Alignment.CenterEnd).padding(end = 10.dp)) { trailing() }
    }
}

@Composable
fun GradientButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier.fillMaxWidth().height(54.dp).clip(CircleShape).background(K.Brand).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text(text, color = K.On, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold) }
}

// ---------------------------------------------------------------- нижнее меню

@Composable
fun NavBar(active: String, badge: Int, onNav: (String) -> Unit) {
    val shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
    val dim = ColorFilter.colorMatrix(
        ColorMatrix(floatArrayOf(.62f, 0f, 0f, 0f, 0f, 0f, .62f, 0f, 0f, 0f, 0f, 0f, .62f, 0f, 0f, 0f, 0f, 0f, 1f, 0f)),
    )
    Row(
        Modifier.fillMaxWidth().shadow(10.dp, shape).background(K.Panel, shape)
            .windowInsetsPadding(WindowInsets.navigationBars)
            .padding(start = 10.dp, end = 10.dp, top = 6.dp, bottom = 12.dp),
    ) {
        val items = listOf(
            Triple("list", "Чаты", R.drawable.k_chat),
            Triple("family", "Семья", R.drawable.k_family),
            Triple("profile", "Профиль", R.drawable.k_profile),
        )
        for ((key, label, res) in items) {
            val on = key == active
            Box(Modifier.weight(1f)) {
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).clickable { onNav(key) }.padding(vertical = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(2.dp),
                ) {
                    Box(
                        Modifier.size(44.dp).then(
                            if (on) Modifier.drawBehind {
                                drawCircle(
                                    Brush.radialGradient(listOf(Color(0x8C7951E7), Color.Transparent), center = center, radius = 26.dp.toPx()),
                                )
                            } else Modifier,
                        ),
                        contentAlignment = Alignment.Center,
                    ) {
                        Pic(res, if (on) 41.dp else 38.dp, alpha = if (on) 1f else 0.78f, filter = if (on) null else dim)
                    }
                    Text(label, color = if (on) K.Yellow else K.Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
                if (key == "list" && badge > 0) {
                    Text(
                        if (badge > 99) "99+" else badge.toString(),
                        color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold,
                        modifier = Modifier.align(Alignment.TopCenter).offset(x = 22.dp)
                            .background(K.Berry, CircleShape).padding(horizontal = 6.dp, vertical = 1.dp),
                    )
                }
            }
        }
    }
}

// ---------------------------------------------------------------- окна поверх экрана

class SheetItem(val label: String, val danger: Boolean = false, val icon: @Composable () -> Unit, val onClick: () -> Unit)
class ConfirmData(val title: String, val text: String, val okLabel: String, val onOk: () -> Unit)

class Ui {
    var sheet by mutableStateOf<List<SheetItem>?>(null)
    var confirm by mutableStateOf<ConfirmData?>(null)
}

@Composable
fun SheetOverlay(items: List<SheetItem>, onDismiss: () -> Unit) {
    Box(
        Modifier.fillMaxSize().background(Color(0x99000000)).clickable(onClick = onDismiss),
        contentAlignment = Alignment.BottomCenter,
    ) {
        Column(
            Modifier.fillMaxWidth()
                .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)).background(K.Panel2)
                .clickable(enabled = false) { }
                .windowInsetsPadding(WindowInsets.navigationBars)
                .padding(start = 8.dp, end = 8.dp, top = 12.dp, bottom = 22.dp),
        ) {
            Box(Modifier.align(Alignment.CenterHorizontally).size(40.dp, 4.dp).background(Color(0x33FFFFFF), RoundedCornerShape(4.dp)))
            Box(Modifier.height(10.dp))
            for (item in items) {
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).clickable { onDismiss(); item.onClick() }
                        .padding(horizontal = 16.dp, vertical = 13.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                ) {
                    Box(Modifier.size(42.dp).background(K.Panel, CircleShape), contentAlignment = Alignment.Center) { item.icon() }
                    Text(item.label, color = if (item.danger) K.Danger else K.Ink, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun ConfirmOverlay(c: ConfirmData, onDismiss: () -> Unit) {
    Box(
        Modifier.fillMaxSize().background(Color(0x99000000)).clickable(onClick = onDismiss).padding(28.dp),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(K.Panel2)
                .clickable(enabled = false) { }.padding(24.dp),
        ) {
            Text(c.title, color = K.Ink, fontSize = 22.sp, fontWeight = FontWeight.Medium)
            Box(Modifier.height(12.dp))
            Text(c.text, color = K.Muted, fontSize = 14.sp, lineHeight = 20.sp)
            Box(Modifier.height(20.dp))
            Row(Modifier.align(Alignment.End), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Отмена", color = K.Accent, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clip(CircleShape).clickable(onClick = onDismiss).padding(horizontal = 14.dp, vertical = 10.dp))
                Text(c.okLabel, color = K.Danger, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clip(CircleShape).clickable { onDismiss(); c.onOk() }.padding(horizontal = 14.dp, vertical = 10.dp))
            }
        }
    }
}

@Composable
fun BannerCard(b: Banner, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Row(
        modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 10.dp)
            .shadow(12.dp, RoundedCornerShape(22.dp))
            .clip(RoundedCornerShape(22.dp)).background(K.Panel2)
            .border(1.dp, Color(0x59FFC72C), RoundedCornerShape(22.dp))
            .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Pic(R.drawable.k_chat, 34.dp)
        Column {
            Text(b.title, color = K.Ink, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
            Text(b.body, color = K.Muted, fontSize = 13.sp, maxLines = 1)
        }
    }
}

@Composable
fun ToastCard(text: String, modifier: Modifier = Modifier) {
    Text(
        text, color = K.Ink, fontSize = 14.sp,
        modifier = modifier.shadow(10.dp, CircleShape).background(K.Panel2, CircleShape).padding(horizontal = 16.dp, vertical = 10.dp),
    )
}

val GCOL = listOf(Color(0xFFFFC72C), Color(0xFF7CF2CF), Color(0xFFFF9CC8), Color(0xFF8ACBFF), Color(0xFFC4A8FF), Color(0xFFFFB86B))
fun nameColor(n: String): Color {
    var h = 0
    for (ch in n) h = h * 31 + ch.code
    return GCOL[abs(h) % GCOL.size]
}
