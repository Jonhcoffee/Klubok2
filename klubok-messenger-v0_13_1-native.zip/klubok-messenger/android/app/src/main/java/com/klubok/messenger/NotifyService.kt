package com.klubok.messenger

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.provider.Settings
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/** True while the app screen is visible. In that case the app itself shows new messages and no notification is needed. */
object AppVisibility {
    @Volatile var foreground = false
}

/**
 * Background service: while the app is closed it asks the server for new messages every few seconds
 * and shows a notification. No Google services needed. Android requires a small permanent
 * notification ("Клубок работает") for this kind of service.
 */
class NotifyService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannels(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val note = NotificationCompat.Builder(this, CH_SERVICE)
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle("Клубок работает")
            .setContentText("Ждём новые сообщения")
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setOngoing(true)
            .setContentIntent(openAppIntent(this))
            .build()
        val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_REMOTE_MESSAGING else 0
        ServiceCompat.startForeground(this, ONGOING_ID, note, type)
        if (job == null) job = scope.launch { loop() }
        return START_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        job = null
        super.onDestroy()
    }

    private suspend fun loop() {
        val store = SessionStore(applicationContext)
        val seenPrefs = applicationContext.getSharedPreferences("klubok_notify", MODE_PRIVATE)
        var api: MessengerApi? = null
        var base = ""
        while (scope.isActive) {
            if (store.token.isEmpty()) { stopSelf(); return } // logged out
            val b = normalizeServerUrl(store.server)
            if (b != null && (api == null || b != base)) {
                base = b
                api = createApi(b) { store.token }
            }
            try {
                val list = api?.conversations().orEmpty()
                for (c in list) {
                    val last = c.last ?: continue
                    if (c.unread == 0 || last.fromId == store.userId) {
                        NotificationManagerCompat.from(this).cancel(c.user.id.hashCode())
                        continue
                    }
                    if (AppVisibility.foreground) continue
                    val key = "seen_${c.user.id}"
                    if (seenPrefs.getString(key, null) != last.id) {
                        showMessage(c.user, last, c.unread)
                        seenPrefs.edit().putString(key, last.id).apply()
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (t: Throwable) {
                if (isUnauthorized(t)) { stopSelf(); return }
                // Server unreachable: maybe the tunnel address changed, look for the new one.
                val topic = store.topic
                if (topic.isNotEmpty()) {
                    val found = fetchTunnelUrl(topic)?.let { normalizeServerUrl(it) }
                    if (found != null && found != base) store.server = found
                }
            }
            delay(if (AppVisibility.foreground) 15_000L else 8_000L)
        }
    }

    @SuppressLint("MissingPermission")
    private fun showMessage(peer: User, last: Message, unread: Int) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        val body = last.text.ifBlank { "Вложение" }
        val n = NotificationCompat.Builder(this, CH_MESSAGES)
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle(peer.username)
            .setContentText(if (unread > 1) "$unread новых: $body" else body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setAutoCancel(true)
            .setContentIntent(openAppIntent(this))
            .build()
        NotificationManagerCompat.from(this).notify(peer.id.hashCode(), n)
    }

    companion object {
        private const val CH_SERVICE = "klubok_service"
        private const val CH_MESSAGES = "klubok_messages"
        private const val ONGOING_ID = 1

        private fun openAppIntent(ctx: Context): PendingIntent = PendingIntent.getActivity(
            ctx, 0,
            Intent(ctx, com.klubok.messenger.app.NativeActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

        fun createChannels(ctx: Context) {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(
                NotificationChannel(CH_MESSAGES, "Сообщения", NotificationManager.IMPORTANCE_HIGH)
            )
            nm.createNotificationChannel(
                NotificationChannel(CH_SERVICE, "Фоновое соединение", NotificationManager.IMPORTANCE_MIN)
            )
        }

        fun start(ctx: Context) {
            runCatching { ContextCompat.startForegroundService(ctx, Intent(ctx, NotifyService::class.java)) }
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, NotifyService::class.java))
        }

        /** Once per install: ask Android not to put the app to sleep, otherwise notifications can be delayed. */
        fun askBatteryExemption(ctx: Context) {
            val prefs = ctx.getSharedPreferences("klubok_notify", Context.MODE_PRIVATE)
            if (prefs.getBoolean("asked_battery", false)) return
            val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
            if (pm.isIgnoringBatteryOptimizations(ctx.packageName)) return
            prefs.edit().putBoolean("asked_battery", true).apply()
            runCatching {
                ctx.startActivity(
                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${ctx.packageName}"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
        }
    }
}
