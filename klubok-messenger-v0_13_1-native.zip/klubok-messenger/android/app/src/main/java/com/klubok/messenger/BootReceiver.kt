package com.klubok.messenger

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** After the phone restarts, start listening for messages again (if the user is logged in). */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED && SessionStore(context).token.isNotEmpty()) {
            NotifyService.start(context)
        }
    }
}
