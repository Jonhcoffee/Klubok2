@file:OptIn(androidx.compose.ui.ExperimentalComposeUiApi::class)

package com.klubok.messenger.app

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.matchParentSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.union
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.BiasAlignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.klubok.messenger.R
import java.text.BreakIterator

private val EMO: List<Pair<String, List<String>>> = listOf(
    "😊" to "😀 😃 😄 😁 😆 😅 😂 🤣 🙂 😉 😊 😇 🥰 😍 🤩 😘 😋 😎 🥳 😏 🤗 🤭 🤔 🙄 😴 😢 😭 😡 😱 🥺 😬 🤯 😜 🤪 😌".split(" "),
    "👍" to "👍 👎 👌 ✌️ 🤞 🤝 🙏 👏 🙌 💪 👋 🫶 ☝️ 👀 🔥 ✨ 💯 🎉 🙈 🙉 🙊 💥 ⭐ 🌟 ✅ ❌ ❗ ❓ 💤 💬".split(" "),
    "❤️" to "❤️ 🧡 💛 💚 💙 💜 🖤 🤍 💖 💕 💞 💘 💝 💓 💗 😻 💋 🌹 🌷 🌸 🥂 🎁 💐 🫂".split(" "),
    "🍕" to "🍕 🍔 🍟 🌭 🍿 🍩 🍪 🍰 🎂 🍫 🍎 🍓 🍌 🥑 🍅 🥐 🥖 ☕ 🍵 🍺 🍷 🥤 🚗 ✈️ 🏠 🎵 ⚽ 🐶 🐱 🌞 🌙 🌈 ☀️ ⛄".split(" "),
)

private sealed class Item {
    class Day(val label: String) : Item()
    class Bubble(val m: Msg, val swap: Boolean) : Item()
}

private fun buildItems(list: List<Msg>): List<Item> {
    val out = ArrayList<Item>()
    var prevAt: Long? = null
    var prevFrom: String? = null
    for (m in list) {
        val pa = prevAt
        if (pa == null || !sameDay(m.at, pa)) { out.add(Item.Day(dayLabel(m.at))); prevFrom = null }
        prevAt = m.at
        if (m.sys) { out.add(Item.Day(m.text)); prevFrom = null; continue }
        out.add(Item.Bubble(m, prevFrom != null && prevFrom != m.from))
        prevFrom = m.from
    }
    return out
}

/** Две жёлтые галочки с подсветом (одна — отправлено, две — прочитано), как в демо. */
@Composable
fun Ticks(read: Boolean) {
    Canvas(Modifier.size(21.dp, 13.dp)) {
        val s = size.width / 22f
        val p1 = path1
        val p2 = path2
        val glow = Color(0xFFFFC72C)
        val core = if (read) Color(0xFFFFD24A) else Color(0xFFFFC72C).copy(alpha = 0.85f)
        val layers: List<Pair<Float, Float>> =
            if (read) listOf(2.3f + 13f to 0.12f, 2.3f + 8f to 0.22f, 2.3f + 4f to 0.40f)
            else listOf(2.3f + 8f to 0.10f, 2.3f + 4f to 0.22f)
        withTransform({ scale(s, s, Offset.Zero) }) {
            val ps = if (read) listOf(p1, p2) else listOf(p1)
            for ((w, a) in layers) for (p in ps) {
                drawPath(p, glow.copy(alpha = a), style = Stroke(width = w, cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
            for (p in ps) drawPath(p, core, style = Stroke(width = 2.3f, cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
    }
}

private val path1 by lazy { androidx.compose.ui.graphics.vector.PathParser().parsePathString("M1.5 7.5L5.2 11 12 2.8").toPath() }
private val path2 by lazy { androidx.compose.ui.graphics.vector.PathParser().parsePathString("M7.4 7.5L11.1 11 17.9 2.8").toPath() }

@Composable
private fun MsgBubble(m: Msg, mine: Boolean, swap: Boolean, isGr: Boolean, seen: Boolean, senderName: String?) {
    val ec = emojiCount(m.text)
    val maxW = ((LocalConfiguration.current.screenWidthDp - 20) * 0.78f).dp
    val mineShape = RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp, bottomEnd = 6.dp, bottomStart = 18.dp)
    val otherShape = RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp, bottomEnd = 18.dp, bottomStart = 6.dp)
    Row(
        Modifier.fillMaxWidth().padding(top = if (swap) 8.dp else 2.dp),
        horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start,
    ) {
        val base = Modifier.widthIn(max = maxW)
        val bubbleMod = if (ec > 0) base.padding(horizontal = 4.dp, vertical = 2.dp)
        else if (mine) base.clip(mineShape).background(Brush.linearGradient(listOf(Color(0xFF4456EC), Color(0xFF3946EA)))).padding(start = 12.dp, end = 12.dp, top = 6.dp, bottom = 4.dp)
        else base.clip(otherShape).background(Color(0xFF4337AF)).padding(start = 12.dp, end = 12.dp, top = 6.dp, bottom = 4.dp)
        Column(bubbleMod) {
            if (isGr && !mine && senderName != null) {
                Text(senderName, color = nameColor(senderName), fontSize = 11.8.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(bottom = 1.dp))
            }
            if (m.text.isNotEmpty()) {
                val fs = when (ec) { 1 -> 83.sp; 2 -> 64.sp; 3 -> 50.sp; else -> 15.sp }
                Text(
                    m.text,
                    color = if (mine && ec == 0) K.On else K.Ink,
                    fontSize = fs,
                    lineHeight = if (ec > 0) fs * 1.15f else 20.sp,
                )
            }
            Row(
                Modifier.align(Alignment.End),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(5.dp),
            ) {
                val metaColor = if (mine && ec == 0) Color(0xA6000000) else K.Muted
                if (m.pending) {
                    Text("отправка…", color = metaColor, fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold)
                } else {
                    Text(hm(m.at), color = metaColor, fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold)
                    if (mine) Ticks(seen)
                }
            }
        }
    }
}

private fun insertEmoji(tf: TextFieldValue, e: String): TextFieldValue {
    val a = tf.selection.min
    val b = tf.selection.max
    if (tf.text.length - (b - a) + e.length > 5000) return tf
    return TextFieldValue(tf.text.substring(0, a) + e + tf.text.substring(b), TextRange(a + e.length))
}

private fun backspace(tf: TextFieldValue): TextFieldValue {
    val a = tf.selection.min
    val b = tf.selection.max
    if (a != b) return TextFieldValue(tf.text.substring(0, a) + tf.text.substring(b), TextRange(a))
    if (a == 0) return tf
    val bi = BreakIterator.getCharacterInstance()
    bi.setText(tf.text)
    var prev = bi.preceding(a)
    if (prev == BreakIterator.DONE) prev = a - 1
    return TextFieldValue(tf.text.substring(0, prev) + tf.text.substring(a), TextRange(prev))
}

@Composable
fun ChatScreen(store: Store, ui: Ui, peerId: String, onBack: () -> Unit) {
    val peer = store.userById(peerId)
    if (peer == null) {
        LaunchedEffect(Unit) { onBack() }
        return
    }
    val isGr = isG(peerId)
    val grp = if (isGr) store.db.groups.find { it.id == peerId } else null
    val me = store.db.me ?: ""
    val typingName = store.typing[peerId]
    val blocked = store.isBlocked(peerId)

    DisposableEffect(peerId) {
        store.currentChat = peerId
        store.markRead(peerId)
        onDispose { if (store.currentChat == peerId) store.currentChat = null }
    }

    val list = store.thread(peerId)
    val rows = remember(list) { buildItems(list) }
    val readAt = store.db.reads["$peerId:$me"] ?: 0L
    val listState = rememberLazyListState()
    LaunchedEffect(rows.size) { if (rows.isNotEmpty()) listState.scrollToItem(rows.lastIndex) }

    var tf by remember { mutableStateOf(TextFieldValue("")) }
    var emojiOpen by remember { mutableStateOf(false) }
    var tab by remember { mutableStateOf(0) }
    val kb = LocalSoftwareKeyboardController.current
    val focus = LocalFocusManager.current

    fun doSend() {
        val t = tf.text.trim()
        if (t.isEmpty()) { store.toast("Голосовые сообщения — в следующем этапе"); return }
        tf = TextFieldValue("")
        store.send(peerId, t)
    }

    Column(Modifier.fillMaxSize().background(K.Bg)) {
        // ---- шапка ----
        Box(
            Modifier.fillMaxWidth().shadow(8.dp)
                .background(Brush.horizontalGradient(listOf(Color(0xFF1B2D6B), Color(0xFF0E1B39)))),
        ) {
            Image(
                painterResource(R.drawable.k_hero), null,
                Modifier.matchParentSize().alpha(0.7f).fadeMask(
                    Brush.horizontalGradient(0f to Color.Transparent, 0.25f to Color.Transparent, 1f to Color.Black),
                ),
                contentScale = ContentScale.Crop,
                alignment = BiasAlignment(-0.4f, -0.24f),
            )
            Row(
                Modifier.statusBarsPadding().padding(start = 4.dp, end = 12.dp, top = 6.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                IconBtn(onBack) { SvgIcon(Ic.back, K.Ink, 24.dp) }
                AvatarFor(peer, 38.dp)
                Column(Modifier.weight(1f)) {
                    Text(peer.username, color = K.Ink, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    val sub = when {
                        typingName != null -> (if (isGr) "$typingName " else "") + "печатает…"
                        isGr -> "${grp?.members?.size ?: 0} участн."
                        blocked -> "заблокирован(а)"
                        else -> STATUS[peer.username] ?: "личная переписка"
                    }
                    Text(sub, color = if (typingName != null) K.Accent else K.Muted, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                }
                if (!isGr) {
                    IconBtn({ store.toast("Звонки — в следующем этапе") }) { SvgIcon(Ic.phone, K.Ink, 22.dp) }
                    IconBtn({ store.toast("Видеозвонки — в следующем этапе") }) { SvgIcon(Ic.video, K.Ink, 22.dp) }
                }
                IconBtn({
                    val clear = SheetItem("Очистить переписку", danger = true, icon = { SvgIcon(Ic.trash, K.Danger, 21.dp) }, onClick = {
                        ui.confirm = ConfirmData("Очистить переписку?", "Сообщения исчезнут только у вас.", "Очистить") { store.clearChat(peerId) }
                    })
                    ui.sheet = if (isGr) listOf(clear) else listOf(
                        SheetItem(
                            if (blocked) "Разблокировать" else "Заблокировать", danger = !blocked,
                            icon = { SvgIcon(Ic.shield, if (blocked) K.Yellow else K.Danger, 21.dp) },
                            onClick = {
                                val was = blocked
                                store.toggleBlock(peerId)
                                store.toast(if (was) "Разблокирован" else "Заблокирован — сообщения не приходят")
                            },
                        ),
                        clear,
                    )
                }) { DotsIcon(K.Ink, 22.dp) }
            }
        }

        // ---- сообщения ----
        Box(Modifier.weight(1f).fillMaxWidth().deco(spotTopRight = true)) {
            if (list.isEmpty()) {
                Text(
                    "Здесь пока пусто.\nНапишите первое сообщение 👋",
                    color = K.Muted, fontSize = 15.sp, lineHeight = 22.sp,
                    modifier = Modifier.align(Alignment.Center).padding(24.dp),
                )
            }
            LazyColumn(Modifier.fillMaxSize(), state = listState, contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp)) {
                items(rows.size) { i ->
                    when (val row = rows[i]) {
                        is Item.Day -> Box(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 4.dp), contentAlignment = Alignment.Center) {
                            Text(
                                row.label, color = K.Muted, fontSize = 12.5.sp, fontWeight = FontWeight.ExtraBold,
                                modifier = Modifier.background(K.Panel, CircleShape).padding(horizontal = 12.dp, vertical = 3.dp),
                            )
                        }
                        is Item.Bubble -> {
                            val m = row.m
                            val mine = m.from == me
                            val seen = if (isGr) m.rd else (readAt >= m.at && store.db.readRcpt)
                            MsgBubble(m, mine, row.swap, isGr, seen, if (isGr && !mine) store.nameOf(m.from) else null)
                        }
                    }
                }
            }
        }

        // ---- ввод ----
        if (blocked) {
            Column(
                Modifier.fillMaxWidth().background(K.Bg).windowInsetsPadding(WindowInsets.navigationBars).padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text("Вы заблокировали ${peer.username}", color = K.Muted, fontSize = 14.sp)
                Text(
                    "Разблокировать", color = K.Yellow, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold,
                    modifier = Modifier.clip(CircleShape).clickable { store.toggleBlock(peerId); store.toast("Разблокирован") }.padding(8.dp),
                )
            }
        } else {
            Column(Modifier.fillMaxWidth().background(K.Bg).windowInsetsPadding(WindowInsets.ime.union(WindowInsets.navigationBars))) {
                val has = tf.text.isNotBlank()
                Row(
                    Modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, top = 10.dp, bottom = if (emojiOpen) 8.dp else 14.dp),
                    verticalAlignment = Alignment.Bottom,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Row(
                        Modifier.weight(1f).heightIn(min = 50.dp).background(K.Panel2, RoundedCornerShape(26.dp)),
                        verticalAlignment = Alignment.Bottom,
                    ) {
                        Box(
                            Modifier.size(46.dp, 50.dp).clip(RoundedCornerShape(topStart = 26.dp, bottomStart = 26.dp)).clickable {
                                if (emojiOpen) { emojiOpen = false } else { emojiOpen = true; kb?.hide(); focus.clearFocus() }
                            },
                            contentAlignment = Alignment.Center,
                        ) { Pic(R.drawable.k_smile, 26.dp, alpha = if (emojiOpen) 1f else 0.85f) }
                        BasicTextField(
                            value = tf,
                            onValueChange = { tf = it },
                            textStyle = TextStyle(color = K.On, fontSize = 16.sp, lineHeight = 24.sp, fontWeight = FontWeight.Medium),
                            cursorBrush = SolidColor(K.On),
                            maxLines = 5,
                            modifier = Modifier.weight(1f).padding(vertical = 13.dp).onFocusChanged { if (it.isFocused && emojiOpen) emojiOpen = false },
                            decorationBox = { inner ->
                                Box {
                                    if (tf.text.isEmpty()) Text("Сообщение", color = K.Fg, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                                    inner()
                                }
                            },
                        )
                        Box(
                            Modifier.size(46.dp, 50.dp).clip(RoundedCornerShape(topEnd = 26.dp, bottomEnd = 26.dp))
                                .clickable { store.toast("Вложения — в следующем этапе") },
                            contentAlignment = Alignment.Center,
                        ) { Pic(R.drawable.k_clip, 26.dp, alpha = 0.85f) }
                    }
                    Box(
                        Modifier.size(50.dp).clip(CircleShape).background(if (has) K.Brand else SolidColor(K.Panel2)).clickable { doSend() },
                        contentAlignment = Alignment.Center,
                    ) {
                        if (has) Pic(R.drawable.k_send, 26.dp) else SvgIcon(Ic.mic, K.Muted, 23.dp)
                    }
                }
                if (emojiOpen) {
                    Column(
                        Modifier.padding(start = 12.dp, end = 12.dp, bottom = 12.dp).fillMaxWidth().height(232.dp)
                            .clip(RoundedCornerShape(24.dp)).background(K.Panel2),
                    ) {
                        Row(Modifier.padding(start = 8.dp, end = 8.dp, top = 6.dp, bottom = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                            EMO.forEachIndexed { i, t ->
                                Box(
                                    Modifier.size(40.dp, 38.dp).clip(RoundedCornerShape(13.dp))
                                        .background(if (i == tab) K.Panel else Color.Transparent).clickable { tab = i },
                                    contentAlignment = Alignment.Center,
                                ) { Text(t.first, fontSize = 20.sp) }
                            }
                            Box(Modifier.weight(1f))
                            Box(
                                Modifier.size(40.dp, 38.dp).clip(RoundedCornerShape(13.dp)).clickable { tf = backspace(tf) },
                                contentAlignment = Alignment.Center,
                            ) { SvgIcon(Ic.bksp, K.Muted, 24.dp) }
                        }
                        LazyVerticalGrid(
                            GridCells.Fixed(7), Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(start = 8.dp, end = 8.dp, top = 4.dp, bottom = 10.dp),
                        ) {
                            items(EMO[tab].second) { e ->
                                Box(
                                    Modifier.aspectRatio(1f).clip(RoundedCornerShape(14.dp)).clickable { tf = insertEmoji(tf, e) },
                                    contentAlignment = Alignment.Center,
                                ) { Text(e, fontSize = 27.sp) }
                            }
                        }
                    }
                }
            }
        }
    }
}
