package com.klubok.messenger.app

import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

const val HOUR = 3_600_000L
const val DAY = 24 * HOUR

fun now(): Long = System.currentTimeMillis()
fun rid(): String = java.util.UUID.randomUUID().toString().take(8)
fun isG(id: String): Boolean = id.startsWith("g_")

fun hash(s: String): String {
    val d = MessageDigest.getInstance("SHA-256").digest(("klubok:$s").toByteArray())
    return d.joinToString("") { "%02x".format(it) }
}

private val RU = Locale("ru")

fun hm(t: Long): String = SimpleDateFormat("HH:mm", RU).format(Date(t))

private fun dayKey(t: Long): Int {
    val c = Calendar.getInstance(); c.timeInMillis = t
    return c.get(Calendar.YEAR) * 400 + c.get(Calendar.DAY_OF_YEAR)
}

fun sameDay(a: Long, b: Long): Boolean = dayKey(a) == dayKey(b)

fun dayLabel(t: Long): String = when {
    sameDay(t, now()) -> "Сегодня"
    sameDay(t, now() - DAY) -> "Вчера"
    else -> SimpleDateFormat("d MMMM", RU).format(Date(t))
}

fun listTime(t: Long): String = when {
    sameDay(t, now()) -> hm(t)
    sameDay(t, now() - DAY) -> "Вчера"
    else -> SimpleDateFormat("dd.MM.yy", RU).format(Date(t))
}

/** Сколько смайликов в сообщении, если там ТОЛЬКО 1–3 смайлика (иначе 0). */
fun emojiCount(text: String): Int {
    val t = text.trim()
    if (t.isEmpty()) return 0
    var n = 0
    var i = 0
    var prevJoin = false
    var regional = 0
    while (i < t.length) {
        val cp = t.codePointAt(i)
        i += Character.charCount(cp)
        if (Character.isWhitespace(cp)) { prevJoin = false; continue }
        when {
            cp == 0x200D -> { prevJoin = true }
            cp == 0xFE0F || cp == 0xFE0E || cp == 0x20E3 || cp in 0x1F3FB..0x1F3FF || cp in 0xE0020..0xE007F -> { }
            cp in 0x1F1E6..0x1F1FF -> { regional++; if (regional % 2 == 1) n++ ; prevJoin = false }
            isEmojiBase(cp) -> { if (!prevJoin) n++; prevJoin = false }
            else -> return 0
        }
    }
    return if (n in 1..3) n else 0
}

private fun isEmojiBase(cp: Int): Boolean =
    cp in 0x1F300..0x1FAFF || cp in 0x1F000..0x1F2FF || cp in 0x2600..0x27BF || cp in 0x2B00..0x2BFF ||
        cp in 0x2190..0x21FF || cp in 0x2300..0x23FF || cp in 0x25AA..0x25FE || cp in 0x2934..0x2935 ||
        cp == 0x00A9 || cp == 0x00AE || cp == 0x203C || cp == 0x2049 || cp == 0x2122 || cp == 0x2139 ||
        cp == 0x24C2 || cp == 0x3030 || cp == 0x303D || cp == 0x3297 || cp == 0x3299
