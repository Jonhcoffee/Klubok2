const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const app = express();
app.set('trust proxy', 1);
const PORT = Number(process.env.PORT || 3000);
const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET || JWT_SECRET.length < 32) {
  console.error('Set JWT_SECRET to a random secret of at least 32 characters.');
  process.exit(1);
}
const DATA_DIR = path.join(__dirname, '..', 'data');
const UPLOAD_DIR = path.join(DATA_DIR, 'uploads');
fs.mkdirSync(UPLOAD_DIR, { recursive: true });
const DB_FILE = path.join(DATA_DIR, 'db.json');
if (!fs.existsSync(DB_FILE)) fs.writeFileSync(DB_FILE, JSON.stringify({ users: [], messages: [] }, null, 2));
let db = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
db.users = db.users || [];
db.messages = db.messages || [];
db.reads = db.reads || {}; // "readerId:peerId" -> ISO time of the last time reader opened the chat with peer
db.groups = db.groups || [];      // { id, name, ownerId, memberIds[], avatar, createdAt }
db.files = db.files || {};        // fileId -> { ownerId, name, mime, size, kind, dur }
db.devices = db.devices || [];    // push-токены устройств { userId, token, platform, at }
db.calls = db.calls || [];        // заготовка сигналинга звонков
db.families = db.families || [];  // семейные пространства
db.sessions = db.sessions || [];  // активные входы { id, userId, device, ip, at, lastAt }
// Atomic write: a crash in the middle of saving can no longer corrupt db.json.
function save() {
  const tmp = DB_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(db));
  fs.renameSync(tmp, DB_FILE);
}

// Very small brute-force protection for login/registration.
const fails = new Map();
const MAX_FAILS = 8, FAIL_WINDOW_MS = 10 * 60 * 1000;
function isLimited(key) { const e = fails.get(key); return !!e && e.until > Date.now() && e.count >= MAX_FAILS; }
function noteFail(key) {
  const now = Date.now(); const e = fails.get(key);
  if (!e || e.until <= now) fails.set(key, { count: 1, until: now + FAIL_WINDOW_MS }); else e.count++;
}
setInterval(() => { const now = Date.now(); for (const [k, e] of fails) if (e.until <= now) fails.delete(k); }, FAIL_WINDOW_MS).unref();
const PRIV_DEFAULT = { lastSeen: 'all', readReceipts: true, whoCanWrite: 'all' };
function priv(u) { return { ...PRIV_DEFAULT, ...(u.privacy || {}) }; }
function safeUser(u) {
  return { id: u.id, username: u.username, displayName: u.displayName || u.username, bio: u.bio || '', avatar: u.avatar || null, phone: u.phone || null, createdAt: u.createdAt };
}
function publicUser(u, viewerId) {
  const p = priv(u); const out = safeUser(u); delete out.phone;
  out.lastSeenAt = (p.lastSeen === 'all' && u.lastSeenAt) ? u.lastSeenAt : null;
  return out;
}
function issueToken(user, req) {
  const sid = crypto.randomUUID();
  db.sessions.push({ id: sid, userId: user.id, device: String(req.headers['user-agent'] || 'unknown').slice(0, 120), ip: req.ip, at: new Date().toISOString(), lastAt: new Date().toISOString() });
  db.sessions = db.sessions.filter(x => x.userId !== user.id || true).slice(-500);
  return jwt.sign({ id: user.id, username: user.username, sid, tv: user.tokenVersion || 0 }, JWT_SECRET, { expiresIn: '30d' });
}
function auth(req, res, next) {
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  try {
    if (!token) throw new Error('missing');
    const p = jwt.verify(token, JWT_SECRET);
    const u = db.users.find(x => x.id === p.id);
    if (!u || (u.tokenVersion || 0) !== (p.tv || 0)) throw new Error('revoked');
    const ses = db.sessions.find(x => x.id === p.sid);
    if (p.sid && !ses) throw new Error('session ended');
    if (ses) ses.lastAt = new Date().toISOString();
    u.lastSeenAt = new Date().toISOString();
    req.user = p; req.me = u; next();
  } catch { res.status(401).json({ error: 'Требуется войти в аккаунт' }); }
}
app.use(cors());
app.use((_req, res, next) => { res.setHeader('X-Content-Type-Options', 'nosniff'); res.setHeader('X-Frame-Options', 'DENY'); res.setHeader('Referrer-Policy', 'no-referrer'); next(); });
app.use(express.json({ limit: '1mb' }));
app.get('/health', (_req, res) => res.json({ ok: true, service: 'Klubok Messenger API', version: '0.10.0' }));

app.post('/api/auth/register', async (req, res) => {
  const username = String(req.body.username || '').trim();
  const password = String(req.body.password || '');
  const phone = String(req.body.phone || '').trim();
  if (!/^[\p{L}\p{N}_]{3,24}$/u.test(username)) return res.status(400).json({ error: 'Имя: 3–24 символа — буквы, цифры и _' });
  if (password.length < 8 || password.length > 128) return res.status(400).json({ error: 'Пароль должен содержать минимум 8 символов' });
  if (db.users.some(u => u.username.toLowerCase() === username.toLowerCase())) return res.status(409).json({ error: 'Это имя уже занято' });
  if (phone && db.users.some(u => u.phone === phone)) return res.status(409).json({ error: 'Этот номер уже привязан к аккаунту' });
  const user = { id: crypto.randomUUID(), username, passwordHash: await bcrypt.hash(password, 12), phone: phone || null, createdAt: new Date().toISOString() };
  db.users.push(user); save();
  res.status(201).json({ token: issueToken(user, req), user: safeUser(user) });
});
app.post('/api/auth/login', async (req, res) => {
  const username = String(req.body.username || '').trim();
  const password = String(req.body.password || '');
  const limitKey = `${req.ip}:${username.toLowerCase()}`;
  if (isLimited(limitKey)) return res.status(429).json({ error: 'Слишком много попыток. Подождите несколько минут.' });
  const user = db.users.find(u => u.username.toLowerCase() === username.toLowerCase());
  if (!user || !(await bcrypt.compare(password, user.passwordHash))) { noteFail(limitKey); return res.status(401).json({ error: 'Неверное имя пользователя или пароль' }); }
  res.json({ token: issueToken(user, req), user: safeUser(user) });
});
app.get('/api/users', auth, (req, res) => {
  const q = String(req.query.q || '').trim().toLowerCase();
  res.json(db.users.filter(u => u.id !== req.user.id && (!q || u.username.toLowerCase().includes(q))).slice(0, 100).map(u => publicUser(u)));
});

// ======================= профиль и аватар =======================
app.get('/api/me', auth, (req, res) => res.json({ user: safeUser(req.me), privacy: priv(req.me), blocked: req.me.blocked || [] }));
app.patch('/api/me', auth, (req, res) => {
  const u = req.me;
  if (req.body.displayName !== undefined) {
    const n = String(req.body.displayName).trim();
    if (n.length > 40) return res.status(400).json({ error: 'Имя слишком длинное (до 40 символов)' });
    u.displayName = n || u.username;
  }
  if (req.body.bio !== undefined) {
    const b = String(req.body.bio).trim();
    if (b.length > 200) return res.status(400).json({ error: 'О себе: до 200 символов' });
    u.bio = b;
  }
  if (req.body.avatar !== undefined) {
    const a = req.body.avatar === null ? null : String(req.body.avatar);
    if (a && !(db.files[a] && db.files[a].ownerId === u.id && db.files[a].kind === 'photo')) return res.status(400).json({ error: 'Сначала загрузите фото через /api/files' });
    u.avatar = a;
  }
  save(); res.json(safeUser(u));
});
app.get('/api/users/:id', auth, (req, res) => {
  const u = db.users.find(x => x.id === req.params.id);
  if (!u) return res.status(404).json({ error: 'Пользователь не найден' });
  res.json(publicUser(u));
});

// ======================= безопасность и приватность =======================
app.get('/api/privacy', auth, (req, res) => res.json(priv(req.me)));
app.put('/api/privacy', auth, (req, res) => {
  const b = req.body || {}, p = priv(req.me);
  if (b.lastSeen !== undefined) { if (!['all', 'contacts', 'nobody'].includes(b.lastSeen)) return res.status(400).json({ error: 'Некорректное значение' }); p.lastSeen = b.lastSeen; }
  if (b.whoCanWrite !== undefined) { if (!['all', 'contacts'].includes(b.whoCanWrite)) return res.status(400).json({ error: 'Некорректное значение' }); p.whoCanWrite = b.whoCanWrite; }
  if (b.readReceipts !== undefined) p.readReceipts = !!b.readReceipts;
  req.me.privacy = p; save(); res.json(p);
});
app.post('/api/security/password', auth, async (req, res) => {
  const cur = String(req.body.currentPassword || ''), next = String(req.body.newPassword || '');
  const key = `pw:${req.user.id}`;
  if (isLimited(key)) return res.status(429).json({ error: 'Слишком много попыток. Подождите несколько минут.' });
  if (!(await bcrypt.compare(cur, req.me.passwordHash))) { noteFail(key); return res.status(401).json({ error: 'Текущий пароль неверный' }); }
  if (next.length < 8 || next.length > 128) return res.status(400).json({ error: 'Новый пароль: минимум 8 символов' });
  req.me.passwordHash = await bcrypt.hash(next, 12);
  req.me.tokenVersion = (req.me.tokenVersion || 0) + 1;   // все старые токены перестают работать
  db.sessions = db.sessions.filter(x => x.userId !== req.me.id);
  const token = issueToken(req.me, req); save();
  res.json({ token, message: 'Пароль изменён. На других устройствах нужно войти заново.' });
});
app.get('/api/security/sessions', auth, (req, res) => {
  res.json(db.sessions.filter(x => x.userId === req.user.id).map(x => ({ id: x.id, device: x.device, ip: x.ip, at: x.at, lastAt: x.lastAt, current: x.id === req.user.sid })));
});
app.delete('/api/security/sessions/:id', auth, (req, res) => {
  const before = db.sessions.length;
  db.sessions = db.sessions.filter(x => !(x.id === req.params.id && x.userId === req.user.id));
  if (db.sessions.length === before) return res.status(404).json({ error: 'Сеанс не найден' });
  save(); res.json({ ok: true });
});
app.post('/api/security/logout-others', auth, (req, res) => {
  db.sessions = db.sessions.filter(x => x.userId !== req.user.id || x.id === req.user.sid);
  save(); res.json({ ok: true });
});
app.get('/api/blocked', auth, (req, res) => res.json(req.me.blocked || []));
app.put('/api/blocked/:userId', auth, (req, res) => {
  if (req.params.userId === req.me.id) return res.status(400).json({ error: 'Нельзя заблокировать себя' });
  if (!db.users.some(u => u.id === req.params.userId)) return res.status(404).json({ error: 'Пользователь не найден' });
  req.me.blocked = [...new Set([...(req.me.blocked || []), req.params.userId])]; save(); res.json(req.me.blocked);
});
app.delete('/api/blocked/:userId', auth, (req, res) => {
  req.me.blocked = (req.me.blocked || []).filter(x => x !== req.params.userId); save(); res.json(req.me.blocked);
});
app.get('/api/account/export', auth, (req, res) => {
  const me = req.me.id;
  res.json({ user: safeUser(req.me), privacy: priv(req.me), messages: db.messages.filter(m => m.fromId === me || m.toId === me),
    groups: db.groups.filter(g => g.memberIds.includes(me)), exportedAt: new Date().toISOString() });
});
app.delete('/api/account', auth, async (req, res) => {
  if (!(await bcrypt.compare(String(req.body.password || ''), req.me.passwordHash))) return res.status(401).json({ error: 'Пароль неверный' });
  const me = req.me.id;
  db.messages = db.messages.filter(m => m.fromId !== me && m.toId !== me);
  db.groups.forEach(g => { g.memberIds = g.memberIds.filter(x => x !== me); });
  db.groups = db.groups.filter(g => g.memberIds.length > 0);
  db.sessions = db.sessions.filter(x => x.userId !== me);
  db.devices = db.devices.filter(x => x.userId !== me);
  db.users = db.users.filter(u => u.id !== me); save(); res.json({ ok: true });
});

// ======================= личные и групповые чаты =======================
const isGroupId = id => db.groups.some(g => g.id === id);
const groupOf = (id, me) => db.groups.find(g => g.id === id && g.memberIds.includes(me));
const lastMsgText = m => m.attachment ? ({ photo: '📷 Фото', video: '🎞 Видео', voice: '🎤 Голосовое', file: '📎 ' + (m.attachment.name || 'Файл') }[m.attachment.kind] || '📎 Файл') : m.text;

app.post('/api/groups', auth, (req, res) => {
  const name = String(req.body.name || '').trim();
  const ids = [...new Set((Array.isArray(req.body.memberIds) ? req.body.memberIds : []).map(String))].filter(id => id !== req.user.id && db.users.some(u => u.id === id));
  if (name.length < 1 || name.length > 60) return res.status(400).json({ error: 'Название группы: 1–60 символов' });
  if (ids.length < 1) return res.status(400).json({ error: 'Добавьте хотя бы одного участника' });
  if (ids.length > 199) return res.status(400).json({ error: 'В группе может быть до 200 участников' });
  const g = { id: crypto.randomUUID(), name, ownerId: req.user.id, memberIds: [req.user.id, ...ids], avatar: null, createdAt: new Date().toISOString() };
  db.groups.push(g);
  db.messages.push({ id: crypto.randomUUID(), fromId: req.user.id, toId: g.id, text: 'Группа создана', system: true, attachment: null, createdAt: g.createdAt });
  save(); res.status(201).json(g);
});
app.get('/api/groups/:id', auth, (req, res) => {
  const g = groupOf(req.params.id, req.user.id); if (!g) return res.status(404).json({ error: 'Группа не найдена' });
  res.json({ ...g, members: g.memberIds.map(id => db.users.find(u => u.id === id)).filter(Boolean).map(u => publicUser(u)) });
});
app.patch('/api/groups/:id', auth, (req, res) => {
  const g = groupOf(req.params.id, req.user.id); if (!g) return res.status(404).json({ error: 'Группа не найдена' });
  if (g.ownerId !== req.user.id) return res.status(403).json({ error: 'Менять группу может только создатель' });
  if (req.body.name !== undefined) { const n = String(req.body.name).trim(); if (!n || n.length > 60) return res.status(400).json({ error: 'Название группы: 1–60 символов' }); g.name = n; }
  if (Array.isArray(req.body.addIds)) for (const id of req.body.addIds.map(String)) if (db.users.some(u => u.id === id) && !g.memberIds.includes(id)) g.memberIds.push(id);
  if (Array.isArray(req.body.removeIds)) g.memberIds = g.memberIds.filter(id => id === g.ownerId || !req.body.removeIds.includes(id));
  save(); res.json(g);
});
app.post('/api/groups/:id/leave', auth, (req, res) => {
  const g = groupOf(req.params.id, req.user.id); if (!g) return res.status(404).json({ error: 'Группа не найдена' });
  g.memberIds = g.memberIds.filter(id => id !== req.user.id);
  if (g.ownerId === req.user.id && g.memberIds.length) g.ownerId = g.memberIds[0];
  if (!g.memberIds.length) db.groups = db.groups.filter(x => x.id !== g.id);
  save(); res.json({ ok: true });
});

app.get('/api/conversations', auth, (req, res) => {
  const me = req.user.id;
  const by = new Map();
  for (const m of db.messages) {
    const g = isGroupId(m.toId) ? groupOf(m.toId, me) : null;
    if (isGroupId(m.toId) && !g) continue;
    if (!g && m.fromId !== me && m.toId !== me) continue;
    const key = g ? g.id : (m.fromId === me ? m.toId : m.fromId);
    let c = by.get(key); if (!c) { c = { last: m, unread: 0, group: g }; by.set(key, c); }
    c.last = m;
    if (!m.system && m.fromId !== me && m.createdAt > (db.reads[`${me}:${key}`] || '')) c.unread++;
  }
  const out = [];
  for (const [key, c] of by) {
    const last = { ...c.last, preview: lastMsgText(c.last) };
    if (c.group) out.push({ group: { id: c.group.id, name: c.group.name, avatar: c.group.avatar, memberCount: c.group.memberIds.length }, user: null, last, unread: c.unread });
    else { const u = db.users.find(x => x.id === key); if (u) out.push({ user: publicUser(u), group: null, last, unread: c.unread }); }
  }
  out.sort((a, b) => b.last.createdAt.localeCompare(a.last.createdAt));
  res.json(out);
});
app.get('/api/messages/:id', auth, (req, res) => {
  const me = req.user.id, otherId = req.params.id;
  const g = isGroupId(otherId) ? groupOf(otherId, me) : null;
  if (isGroupId(otherId) && !g) return res.status(403).json({ error: 'Вы не состоите в этой группе' });
  if (!g && !db.users.some(u => u.id === otherId)) return res.status(404).json({ error: 'Пользователь не найден' });
  const messages = g ? db.messages.filter(m => m.toId === g.id)
    : db.messages.filter(m => (m.fromId === me && m.toId === otherId) || (m.fromId === otherId && m.toId === me));
  const key = `${me}:${otherId}`, prev = db.reads[key] || '';
  if (messages.some(m => m.fromId !== me && m.createdAt > prev)) { db.reads[key] = new Date().toISOString(); save(); }
  const peer = g ? null : db.users.find(u => u.id === otherId);
  // если собеседник отключил отчёты о прочтении — «прочитано» не показываем
  const peerReadAt = (peer && priv(peer).readReceipts) ? (db.reads[`${otherId}:${me}`] || null) : null;
  res.json({ messages: messages.slice(-300), peerReadAt });
});
app.post('/api/messages', auth, (req, res) => {
  const me = req.user.id, toId = String(req.body.toId || '');
  const text = String(req.body.text || '').trim();
  const g = isGroupId(toId) ? groupOf(toId, me) : null;
  if (isGroupId(toId) && !g) return res.status(403).json({ error: 'Вы не состоите в этой группе' });
  const to = g ? null : db.users.find(u => u.id === toId);
  if (!g && !to) return res.status(404).json({ error: 'Получатель не найден' });
  if (to) {
    if ((to.blocked || []).includes(me)) return res.status(403).json({ error: 'Пользователь ограничил получение сообщений от вас' });
    if (priv(to).whoCanWrite === 'contacts' && !db.messages.some(m => m.fromId === to.id && m.toId === me))
      return res.status(403).json({ error: 'Этот пользователь принимает сообщения только от своих контактов' });
  }
  let attachment = null;
  if (req.body.fileId) {
    const f = db.files[String(req.body.fileId)];
    if (!f || f.ownerId !== me) return res.status(400).json({ error: 'Файл не найден — загрузите его заново' });
    attachment = { id: String(req.body.fileId), name: f.name, size: f.size, mime: f.mime, kind: f.kind, dur: f.dur || null };
  }
  if (!attachment && (!text || text.length > 5000)) return res.status(400).json({ error: 'Сообщение должно содержать 1–5000 символов' });
  if (text.length > 5000) return res.status(400).json({ error: 'Подпись слишком длинная' });
  const message = { id: crypto.randomUUID(), fromId: me, toId, text, attachment, createdAt: new Date().toISOString() };
  db.messages.push(message);
  notifyRecipients(message, g, to);
  save(); res.status(201).json(message);
});

// ======================= файлы и медиа =======================
const MEDIA_RE = /^(image\/(jpeg|png|gif|webp)|video\/(mp4|webm|quicktime)|audio\/(webm|ogg|mpeg|mp4|aac|wav|x-m4a)|application\/pdf|text\/plain|application\/zip|application\/vnd\.openxmlformats-officedocument\..+)$/i;
const kindOf = mime => /^image\//.test(mime) ? 'photo' : /^video\//.test(mime) ? 'video' : /^audio\//.test(mime) ? 'voice' : 'file';
const storage = multer.diskStorage({ destination: (_req, _file, cb) => cb(null, UPLOAD_DIR), filename: (_req, file, cb) => cb(null, crypto.randomUUID() + path.extname(file.originalname).replace(/[^.\w]/g, '').slice(0, 12)) });
const upload = multer({ storage, limits: { fileSize: 50 * 1024 * 1024 }, fileFilter: (_req, file, cb) => cb(MEDIA_RE.test(file.mimetype) ? null : new Error('Тип файла не поддерживается'), MEDIA_RE.test(file.mimetype)) });
app.post('/api/files', auth, upload.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'Выберите файл' });
  const kind = kindOf(req.file.mimetype), dur = Math.max(0, Math.min(3600, Number(req.body.duration) || 0)) || null;
  if (kind === 'photo' && req.file.size > 15 * 1024 * 1024) { fs.unlink(req.file.path, () => {}); return res.status(413).json({ error: 'Фото больше 15 МБ' }); }
  const rec = { ownerId: req.user.id, name: path.basename(req.file.originalname).slice(0, 120), mime: req.file.mimetype, size: req.file.size, kind, dur };
  db.files[req.file.filename] = rec; save();
  res.status(201).json({ id: req.file.filename, ...rec, url: `/api/files/${encodeURIComponent(req.file.filename)}` });
});
// доступ к файлу: владелец, участник чата, где файл отправлен, участник семьи (альбом) или просмотр аватара
function canSeeFile(userId, id) {
  const f = db.files[id]; if (!f) return false;
  if (f.ownerId === userId) return true;
  if (db.users.some(u => u.avatar === id)) return true;
  if (db.messages.some(m => m.attachment && m.attachment.id === id && (m.fromId === userId || m.toId === userId || !!groupOf(m.toId, userId)))) return true;
  return db.families.some(fm => fm.memberIds.includes(userId) && fm.album.some(a => a.fileId === id));
}
app.get('/api/files/:id', auth, (req, res) => {
  const id = path.basename(req.params.id), filePath = path.join(UPLOAD_DIR, id);
  if (!fs.existsSync(filePath) || !canSeeFile(req.user.id, id)) return res.status(404).json({ error: 'Файл не найден' });
  const f = db.files[id];
  res.setHeader('X-Content-Type-Options', 'nosniff');
  if (f && f.kind !== 'file') { res.type(f.mime); return res.sendFile(filePath); }  // фото/видео/голосовое играем прямо в приложении
  res.download(filePath, f ? f.name : id);
});

// ======================= уведомления (основа) =======================
// Регистрируем токен устройства. Push через FCM подключается на следующем этапе; пока приложение опрашивает /api/unread.
app.post('/api/devices', auth, (req, res) => {
  const token = String(req.body.token || '').slice(0, 300), platform = String(req.body.platform || 'android').slice(0, 20);
  if (!token) return res.status(400).json({ error: 'Нужен token' });
  db.devices = db.devices.filter(d => d.token !== token);
  db.devices.push({ userId: req.user.id, token, platform, at: new Date().toISOString() }); save(); res.status(201).json({ ok: true });
});
app.delete('/api/devices/:token', auth, (req, res) => { db.devices = db.devices.filter(d => !(d.token === req.params.token && d.userId === req.user.id)); save(); res.json({ ok: true }); });
const pending = new Map(); // userId -> [{ id, title, body, at }] — очередь для будущей отправки push
function notifyRecipients(m, g, to) {
  const ids = g ? g.memberIds.filter(x => x !== m.fromId) : [to.id];
  const sender = db.users.find(u => u.id === m.fromId);
  for (const id of ids) {
    const u = db.users.find(x => x.id === id); if (!u || (u.blocked || []).includes(m.fromId)) continue;
    const q = pending.get(id) || []; q.push({ id: m.id, title: g ? g.name : (sender && sender.displayName), body: lastMsgText(m), chatId: g ? g.id : m.fromId, at: m.createdAt });
    pending.set(id, q.slice(-100));
  }
}
app.get('/api/unread', auth, (req, res) => {
  const me = req.user.id; let total = 0;
  for (const m of db.messages) {
    if (m.system || m.fromId === me) continue;
    const key = isGroupId(m.toId) ? (groupOf(m.toId, me) ? m.toId : null) : (m.toId === me ? m.fromId : null);
    if (key && m.createdAt > (db.reads[`${me}:${key}`] || '')) total++;
  }
  const queue = pending.get(me) || []; pending.set(me, []);
  res.json({ total, notifications: queue });
});

// ======================= звонки (основа сигналинга) =======================
// Сами аудио/видео-потоки (WebRTC) подключим на следующем этапе: тут только вызов, ответ, отказ и завершение.
app.post('/api/calls', auth, (req, res) => {
  const to = db.users.find(u => u.id === String(req.body.toId || ''));
  if (!to) return res.status(404).json({ error: 'Пользователь не найден' });
  if ((to.blocked || []).includes(req.user.id)) return res.status(403).json({ error: 'Вызов недоступен' });
  const call = { id: crypto.randomUUID(), fromId: req.user.id, toId: to.id, video: !!req.body.video, status: 'ringing', createdAt: new Date().toISOString(), answeredAt: null, endedAt: null };
  db.calls.push(call); db.calls = db.calls.slice(-1000); save(); res.status(201).json(call);
});
app.get('/api/calls/incoming', auth, (req, res) => {
  const cutoff = Date.now() - 45000;
  res.json(db.calls.filter(c => c.toId === req.user.id && c.status === 'ringing' && Date.parse(c.createdAt) > cutoff));
});
app.get('/api/calls/:id', auth, (req, res) => {
  const c = db.calls.find(x => x.id === req.params.id && (x.fromId === req.user.id || x.toId === req.user.id));
  if (!c) return res.status(404).json({ error: 'Звонок не найден' }); res.json(c);
});
app.post('/api/calls/:id/:action(answer|decline|end)', auth, (req, res) => {
  const c = db.calls.find(x => x.id === req.params.id && (x.fromId === req.user.id || x.toId === req.user.id));
  if (!c) return res.status(404).json({ error: 'Звонок не найден' });
  const a = req.params.action, now = new Date().toISOString();
  if (a === 'answer') { if (c.toId !== req.user.id || c.status !== 'ringing') return res.status(409).json({ error: 'Ответить нельзя' }); c.status = 'active'; c.answeredAt = now; }
  else if (a === 'decline') { if (c.status !== 'ringing') return res.status(409).json({ error: 'Звонок уже не идёт' }); c.status = 'declined'; c.endedAt = now; }
  else { if (c.status === 'ended' || c.status === 'declined') return res.status(409).json({ error: 'Звонок уже завершён' }); c.status = c.answeredAt ? 'ended' : 'missed'; c.endedAt = now; }
  save(); res.json(c);
});

// ======================= семья: календарь, покупки, заметки, альбом =======================
const famOf = (id, me) => db.families.find(f => f.id === id && f.memberIds.includes(me));
app.post('/api/families', auth, (req, res) => {
  const name = String(req.body.name || 'Семья').trim().slice(0, 40) || 'Семья';
  const f = { id: crypto.randomUUID(), name, ownerId: req.user.id, memberIds: [req.user.id], inviteCode: 'KL-' + crypto.randomBytes(3).toString('hex').toUpperCase(),
    events: [], shopping: [], notes: [], album: [], createdAt: new Date().toISOString() };
  db.families.push(f); save(); res.status(201).json(f);
});
app.get('/api/families', auth, (req, res) => res.json(db.families.filter(f => f.memberIds.includes(req.user.id))));
app.post('/api/families/join', auth, (req, res) => {
  const code = String(req.body.code || '').trim().toUpperCase();
  const f = db.families.find(x => x.inviteCode === code);
  if (!f) return res.status(404).json({ error: 'Код приглашения не найден' });
  if (!f.memberIds.includes(req.user.id)) f.memberIds.push(req.user.id);
  save(); res.json(f);
});
app.post('/api/families/:id/invite-code', auth, (req, res) => {
  const f = famOf(req.params.id, req.user.id); if (!f) return res.status(404).json({ error: 'Семья не найдена' });
  if (f.ownerId !== req.user.id) return res.status(403).json({ error: 'Только создатель может обновить код' });
  f.inviteCode = 'KL-' + crypto.randomBytes(3).toString('hex').toUpperCase(); save(); res.json({ inviteCode: f.inviteCode });
});
app.post('/api/families/:id/leave', auth, (req, res) => {
  const f = famOf(req.params.id, req.user.id); if (!f) return res.status(404).json({ error: 'Семья не найдена' });
  f.memberIds = f.memberIds.filter(x => x !== req.user.id);
  if (f.ownerId === req.user.id && f.memberIds.length) f.ownerId = f.memberIds[0];
  if (!f.memberIds.length) db.families = db.families.filter(x => x.id !== f.id);
  save(); res.json({ ok: true });
});
// одинаковые CRUD-маршруты для четырёх разделов
const clip = (v, n) => String(v === undefined || v === null ? '' : v).trim().slice(0, n);
const FAM = {
  events:   { key: 'events',   build: b => ({ title: clip(b.title, 120), date: clip(b.date, 10), time: clip(b.time, 5), note: clip(b.note, 500) }),
              ok: o => o.title && /^\d{4}-\d{2}-\d{2}$/.test(o.date) && (!o.time || /^\d{2}:\d{2}$/.test(o.time)), err: 'Нужны название и дата (ГГГГ-ММ-ДД)' },
  shopping: { key: 'shopping', build: b => ({ text: clip(b.text, 120), qty: clip(b.qty, 20), done: !!b.done }),
              ok: o => !!o.text, err: 'Введите название товара' },
  notes:    { key: 'notes',    build: b => ({ title: clip(b.title, 80), text: clip(b.text, 5000), color: clip(b.color, 12) || 'yellow', pinned: !!b.pinned }),
              ok: o => o.title || o.text, err: 'Заметка пустая' },
  album:    { key: 'album',    build: b => ({ fileId: clip(b.fileId, 80), caption: clip(b.caption, 200) }),
              ok: o => !!o.fileId, err: 'Нужен fileId загруженного фото' },
};
for (const [route, cfg] of Object.entries(FAM)) {
  app.get(`/api/families/:id/${route}`, auth, (req, res) => {
    const f = famOf(req.params.id, req.user.id); if (!f) return res.status(404).json({ error: 'Семья не найдена' }); res.json(f[cfg.key]);
  });
  app.post(`/api/families/:id/${route}`, auth, (req, res) => {
    const f = famOf(req.params.id, req.user.id); if (!f) return res.status(404).json({ error: 'Семья не найдена' });
    const o = cfg.build(req.body || {}); if (!cfg.ok(o)) return res.status(400).json({ error: cfg.err });
    if (route === 'album') { const rec = db.files[o.fileId]; if (!rec || rec.ownerId !== req.user.id || rec.kind !== 'photo') return res.status(400).json({ error: 'Фото не найдено' }); o.likes = []; }
    if (f[cfg.key].length >= 2000) return res.status(400).json({ error: 'Достигнут лимит записей' });
    const item = { id: crypto.randomUUID(), by: req.user.id, at: new Date().toISOString(), ...o };
    f[cfg.key].push(item); save(); res.status(201).json(item);
  });
  app.patch(`/api/families/:id/${route}/:itemId`, auth, (req, res) => {
    const f = famOf(req.params.id, req.user.id); if (!f) return res.status(404).json({ error: 'Семья не найдена' });
    const item = f[cfg.key].find(x => x.id === req.params.itemId); if (!item) return res.status(404).json({ error: 'Запись не найдена' });
    const merged = cfg.build({ ...item, ...(req.body || {}) });
    if (route === 'album') merged.fileId = item.fileId;
    if (!cfg.ok(merged)) return res.status(400).json({ error: cfg.err });
    Object.assign(item, merged); item.editedAt = new Date().toISOString(); save(); res.json(item);
  });
  app.delete(`/api/families/:id/${route}/:itemId`, auth, (req, res) => {
    const f = famOf(req.params.id, req.user.id); if (!f) return res.status(404).json({ error: 'Семья не найдена' });
    const before = f[cfg.key].length; f[cfg.key] = f[cfg.key].filter(x => x.id !== req.params.itemId);
    if (f[cfg.key].length === before) return res.status(404).json({ error: 'Запись не найдена' });
    save(); res.json({ ok: true });
  });
}
app.post('/api/families/:id/album/:itemId/like', auth, (req, res) => {
  const f = famOf(req.params.id, req.user.id); if (!f) return res.status(404).json({ error: 'Семья не найдена' });
  const it = f.album.find(x => x.id === req.params.itemId); if (!it) return res.status(404).json({ error: 'Фото не найдено' });
  it.likes = it.likes || []; it.likes = it.likes.includes(req.user.id) ? it.likes.filter(x => x !== req.user.id) : [...it.likes, req.user.id];
  save(); res.json(it);
});
app.post('/api/families/:id/shopping-clear', auth, (req, res) => {
  const f = famOf(req.params.id, req.user.id); if (!f) return res.status(404).json({ error: 'Семья не найдена' });
  f.shopping = f.shopping.filter(x => !x.done); save(); res.json(f.shopping);
});

app.use((err, _req, res, _next) => { console.error(err.message); res.status(err instanceof multer.MulterError ? 413 : 400).json({ error: err.message || 'Ошибка запроса' }); });
app.listen(PORT, '0.0.0.0', () => console.log(`Klubok API listening on :${PORT}`));
